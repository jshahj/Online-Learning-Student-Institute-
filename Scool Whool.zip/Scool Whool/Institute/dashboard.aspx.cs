﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;


public partial class Institute_Default : System.Web.UI.Page
{
    void institute_total_data_fill()
    {
        student_details_BAL sdBAL = new student_details_BAL();
        sdBAL.studant_total_value = "1";
        sdBAL.id_id = Convert.ToInt16(Session["institute_login"].ToString());

        student_details_DAL sdDAL = new student_details_DAL();
        int totalstudant = sdDAL.studant_total_data_fill(sdBAL);
        if (totalstudant != null)
        {
            lblstudanttotal.Text = totalstudant.ToString();
        }
    }
    void video_total_data_fill()
    {
        video_master_BAL vmBAL = new video_master_BAL();
        vmBAL.video_institute_id = Convert.ToInt16(Session["institute_login"].ToString());

        video_master_DAL vmDAL = new video_master_DAL();
        int totalvideo = vmDAL.video_total_data_fill_institute(vmBAL);
        if (totalvideo != null)
        {
            lbltotalvideo.Text = totalvideo.ToString();
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["institute_login"] != null)
            {
                institute_total_data_fill();
                video_total_data_fill();
            }
            else
            {
                Response.Redirect("institute_login.aspx");
            }
        }
       

    }
}