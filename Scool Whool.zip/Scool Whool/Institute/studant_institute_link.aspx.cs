﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Institute_studant_institute_link : System.Web.UI.Page
{
    void student_institute_link_data_fill_verification_state()
    {
        student_institute_link_BAL sdlBAL = new student_institute_link_BAL();
        sdlBAL.sil_verification_status = "0";
        sdlBAL.sil_id_id = Session["institute_login"].ToString();

        student_institute_link_DAL sdlDAL = new student_institute_link_DAL();
        DataSet ds = sdlDAL.student_institute_link_data_fill_verification_state(sdlBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["institute_login"] != null)
            {
                student_institute_link_data_fill_verification_state();
            }
            else
            {
                Response.Redirect("institute_login.aspx");
            }
        }
    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "active")
        {
            student_institute_link_BAL sdlBAL = new student_institute_link_BAL();
            sdlBAL.sil_id = Convert.ToInt16(e.CommandArgument.ToString());
            sdlBAL.sil_verification_status = "1";

            student_institute_link_DAL sdlDAL = new student_institute_link_DAL();
            string val = sdlDAL.student_institute_link_update_verification_state(sdlBAL);
            if (val != null)
            {
                Response.Write("<script>alert('Student activation done successfully !!!');window.location.href='studant_institute_link.aspx';</script>");
            }
        }
        if (e.CommandName == "reject")
        {
            student_institute_link_BAL sdlBAL = new student_institute_link_BAL();
            sdlBAL.sil_id = Convert.ToInt16(e.CommandArgument.ToString());
            sdlBAL.sil_verification_status = "2";

            student_institute_link_DAL sdlDAL = new student_institute_link_DAL();
            string val = sdlDAL.student_institute_link_update_verification_state(sdlBAL);
            if (val != null)
            {
                Response.Write("<script>alert('Student Rejected !!!');window.location.href='studant_institute_link.aspx';</script>");
            }
        }
    }
}