﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Institute_insitute_video_show : System.Web.UI.Page
{
    void standard_master_data_fill()
    {
        standard_masterDAL sdDAL = new standard_masterDAL();
        DataSet ds = sdDAL.get_all_standard();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drstandard.DataSource = ds;
            drstandard.DataTextField = "standard_name";
            drstandard.DataValueField = "standard_id";
            drstandard.DataBind();
            drstandard.Items.Insert(0, new ListItem("Select Standard", "0"));
        }
        else
        {
            drstandard.Items.Clear();
            drstandard.Items.Insert(0, new ListItem("Select Standard", "0"));
        }
    }
    void subject_master_data_fill()
    {
        subject_masterDAL smDAL = new subject_masterDAL();
        DataSet ds = smDAL.get_all_subject();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drsubject.DataSource = ds;
            drsubject.DataTextField = "subject_name";
            drsubject.DataValueField = "subject_id";
            drsubject.DataBind();
            drsubject.Items.Insert(0, new ListItem("Select Subject", "0"));
        }
        else
        {
            drsubject.Items.Clear();
            drsubject.Items.Insert(0, new ListItem("Select Subject", "0"));
        }
    }
    void topic_master_data_fill()
    {
        topic_masterBAL tpmBAL = new topic_masterBAL();
        tpmBAL.topic_subject_id = Convert.ToInt16(drsubject.SelectedItem.Value);

        topic_masterDAL rpmDAL = new topic_masterDAL();
        DataSet ds = rpmDAL.topic_drop_down_fill(tpmBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drmaintopic.DataSource = ds;
            drmaintopic.DataTextField = "topic_name";
            drmaintopic.DataValueField = "topic_id";
            drmaintopic.DataBind();
            drmaintopic.Items.Insert(0, new ListItem("Select Main Topic", "0"));
        }
        else
        {
            drmaintopic.Items.Clear();
            drmaintopic.Items.Insert(0, new ListItem("Select Main Topic", "0"));
        }
    }
    void sub_topic_master_data_fill()
    {
        sub_topic_masterBAL stpBAL = new sub_topic_masterBAL();
        stpBAL.sub_topic_topic_id = Convert.ToInt16(drmaintopic.SelectedItem.Value);

        sub_topic_masterDAL stmDAL = new sub_topic_masterDAL();
        DataSet ds = stmDAL.get_sub_topic_for_dropdownfill(stpBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drsubtopic.DataSource = ds;
            drsubtopic.DataTextField = "sub_topic_name";
            drsubtopic.DataValueField = "sub_topic_id";
            drsubtopic.DataBind();
            drsubtopic.Items.Insert(0, new ListItem("Select Sub topic", "0"));
        }
        else
        {
            drsubtopic.Items.Clear();
            drsubtopic.Items.Insert(0, new ListItem("Select Sub topic", "0"));
        }
    }
    void third_topic_master_data_fill()
    {
        third_topic_masterBAL ttpBAL = new third_topic_masterBAL();
        ttpBAL.third_topic_sub_topic_id = Convert.ToInt16(drsubtopic.SelectedItem.Value);

        third_topic_masterDAL ttmDAL = new third_topic_masterDAL();
        DataSet ds = ttmDAL.get_third_topic_for_dropdownfill(ttpBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drthirdtopic.DataSource = ds;
            drthirdtopic.DataTextField = "third_topic_name";
            drthirdtopic.DataValueField = "third_topic_id";
            drthirdtopic.DataBind();
            drthirdtopic.Items.Insert(0, new ListItem("Select Third topic", "0"));
        }
        else
        {
            drthirdtopic.Items.Clear();
            drthirdtopic.Items.Insert(0, new ListItem("Select Third topic", "0"));
        }
    }
    void video_master_data_fill_insitute_page(string videovalue)
    {
        standard_masterBAL sdBAL = new standard_masterBAL();
        sdBAL.institute_video_fill_value = videovalue.ToString();
        sdBAL.id_id = Convert.ToInt16(Session["institute_login"].ToString());
        sdBAL.standard_id = Convert.ToInt16(drstandard.SelectedItem.Value);
        sdBAL.subject_id = Convert.ToInt16(drsubject.SelectedItem.Value);
        sdBAL.topic_id = Convert.ToInt16(drmaintopic.SelectedItem.Value);
        sdBAL.sub_topic_id = Convert.ToInt16(drsubtopic.SelectedItem.Value);
        sdBAL.third_topic_id = Convert.ToInt16(drthirdtopic.SelectedItem.Value);

        institute_data_fill_and_fillter idfafDAL = new institute_data_fill_and_fillter();
        DataSet ds = idfafDAL.video_master_data_fill_insitute_page(sdBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["institute_login"] != null)
        {
            if (!IsPostBack)
            {
                drmaintopic.Items.Insert(0, new ListItem("Select Main Topic", "0"));
                drsubtopic.Items.Insert(0, new ListItem("Select Sub Topic", "0"));
                drthirdtopic.Items.Insert(0, new ListItem("Select Third Topic", "0"));
                standard_master_data_fill();
                subject_master_data_fill();
                video_master_data_fill_insitute_page("0");
            }
        }
        else
        {
            Response.Redirect("institute_login.aspx");
        }
    }
    protected void drstandard_SelectedIndexChanged(object sender, EventArgs e)
    {
        video_master_data_fill_insitute_page("1");
    }
    protected void drsubject_SelectedIndexChanged(object sender, EventArgs e)
    {
        topic_master_data_fill();
        video_master_data_fill_insitute_page("2");
    }
    protected void drmaintopic_SelectedIndexChanged(object sender, EventArgs e)
    {
        sub_topic_master_data_fill();
        video_master_data_fill_insitute_page("3");
    }
    protected void drsubtopic_SelectedIndexChanged(object sender, EventArgs e)
    {
        third_topic_master_data_fill();
        video_master_data_fill_insitute_page("4");
    }
    protected void drthirdtopic_SelectedIndexChanged(object sender, EventArgs e)
    {
        video_master_data_fill_insitute_page("5");
    }
}