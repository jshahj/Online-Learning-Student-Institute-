﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Institute_institute_logout : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userrole"] != null)
        {
            Session["userrole"] = null;
            Session.Clear();
            Session.Abandon();
        }

        if (Session["institute_login"] != null)
        {
            Session["institute_login"] = null;
            Session.Clear();
            Session.Abandon();
        }
        Response.Redirect("institute_login.aspx");
    }
}