﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Institute_institute_login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["userrole"] != null)
        {
            Session["userrole"] = null;
            Session.Clear();
            Session.Abandon();
        }

        if (Session["institute_login"] != null)
        {
            Session["institute_login"] = null;
            Session.Clear();
            Session.Abandon();
        }
    }
    protected void btninstitutelogin_Click(object sender, EventArgs e)
    {
        if (Session["userrole"] != null)
        {
            Session["userrole"] = null;
            Session.Clear();
            Session.Abandon();
        }

        if (Session["institute_login"] != null)
        {
            Session["institute_login"] = null;
            Session.Clear();
            Session.Abandon();
        }
        institute_details_BAL idBAL = new institute_details_BAL();
        idBAL.id_mobile_no = txtmobileno.Text;
        idBAL.id_password = txtpassword.Text;
        institute_details_DAL idDAL = new institute_details_DAL();
        DataSet ds = idDAL.institute_details_login_data_fill(idBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            if (ds.Tables[0].Rows[0]["id_verification_status"].ToString() == "1")
            {
                Session["institute_login"] = ds.Tables[0].Rows[0]["id_id"].ToString();
                Response.Write("<script>alert('Login successfully.');window.location.href='dashboard.aspx';</script>");
            }
            else
            {
                Response.Write("<script>alert('Your Institute in approve to process.');window.location.href='institute_login.aspx';</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('Mobile No or Password Wrong');</script>");

        }



    }
}