﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;

public partial class Institute_institute_notice_add : System.Web.UI.Page
{
    void notice_master_data_fill_rpt()
    {
        notice_master_DAL nmDAL = new notice_master_DAL();
        DataSet ds = nmDAL.notice_master_data_fill();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["institute_login"] != null)
            {
                notice_master_data_fill_rpt();
            }
            else
            {
                Response.Redirect("institute_login.aspx");
            }
        }
    }
    protected void btnnoticeadd_Click(object sender, EventArgs e)
    {
        notice_master_BAL nmBAL = new notice_master_BAL();
        if (hfnotice.Value != null & hfnotice.Value.ToString() != "")
        {
            nmBAL.nm_id = Convert.ToInt16(hfnotice.Value);
        }
        else
        {
            nmBAL.nm_id = 0;

        }
        nmBAL.nm_institute_id = Convert.ToInt16(Session["institute_login"].ToString());
        nmBAL.nm_title = txtnoticetitle.Text;
        nmBAL.nm_description = txtdiscript.Text;
        if (filenotice.HasFile)
        {
            Guid a = Guid.NewGuid();
            hfufdpassextension.Value = Path.GetExtension(filenotice.FileName);
            hfufdpassnewname.Value = a.ToString() + hfufdpassextension.Value;
            filenotice.SaveAs(Server.MapPath("~/institute/noticeimg/" + hfufdpassnewname.Value));
            nmBAL.nm_file_upload = "~/institute/noticeimg/" + hfufdpassnewname.Value;
            //filenotice.SaveAs(Server.MapPath("" + filenotice.FileName));
            //nmBAL.nm_file_upload = "~/institute/noticeimg/" + filenotice.FileName;
        }
        else
        {
            nmBAL.nm_file_upload = fileimage.ImageUrl;
        }
        if (txteffectivedate.Text == "")
        {
            nmBAL.nm_effective_date = Convert.ToDateTime(lblefactfdate.Text);

        }
        else
        {
            nmBAL.nm_effective_date = Convert.ToDateTime(txteffectivedate.Text);

        }
        if (txtineffetivedate.Text == "")
        {
            nmBAL.nm_ineffective_date = Convert.ToDateTime(blbinfectdate.Text);
            
        }
        else
        {
            nmBAL.nm_ineffective_date = Convert.ToDateTime(txtineffetivedate.Text);
        }
        nmBAL.nm_status = "0";
        nmBAL.nm_insdt = System.DateTime.Now;
        nmBAL.nm_insrid = Convert.ToInt16(Session["institute_login"].ToString());
        nmBAL.nm_logdt = System.DateTime.Now;
        nmBAL.nm_logrid = Convert.ToInt16(Session["institute_login"].ToString());

        notice_master_DAL nmDAl = new notice_master_DAL();
        int val = nmDAl.notice_master_insert(nmBAL);
        if (val.ToString() == "1")
        {
            Response.Write("<script>alert('Duplicate Notice Alert(Notice with same title already exists)');</script>");
        }
        else if (val.ToString() == "2")
        {
            Response.Write("<script>alert('Notice board updated');window.location.href='institute_notice_add.aspx';</script>");
        }
        else if (val.ToString() == "3")
        {
            Response.Write("<script>alert('Notice board updated');window.location.href='institute_notice_add.aspx';</script>");
        }
    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "editdata")
        {
            notice_master_BAL nmBAL = new notice_master_BAL();
            nmBAL.nm_id = Convert.ToInt16(e.CommandArgument.ToString());

            notice_master_DAL nmDAL = new notice_master_DAL();
            DataSet ds = nmDAL.notice_master_edit(nmBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                hfnotice.Value = ds.Tables[0].Rows[0]["nm_id"].ToString();
                txtnoticetitle.Text = ds.Tables[0].Rows[0]["nm_title"].ToString();
                txtdiscript.Text = ds.Tables[0].Rows[0]["nm_description"].ToString();
                fileimage.ImageUrl = ds.Tables[0].Rows[0]["nm_file_upload"].ToString();
                lblefactfdate.Text = ds.Tables[0].Rows[0]["nm_effective_date"].ToString().Split(null)[0];
                blbinfectdate.Text = ds.Tables[0].Rows[0]["nm_effective_date"].ToString().Split(null)[0];
                imagenotice.Visible = true;

            }
        }
    }
}