﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Net;

public partial class notice : System.Web.UI.Page
{
    void fill_profile_data()
    {
        student_details_BAL sdBAL = new student_details_BAL();
        sdBAL.stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_details_DAL sdDAL = new student_details_DAL();
        DataSet ds = sdDAL.student_details_edit(sdBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            lbluserName.InnerText = ds.Tables[0].Rows[0]["stud_first_name"].ToString();
        }
    }
    void notice_data_fill_instituteid_rpt()
    {
        notice_master_BAL nmBAL = new notice_master_BAL();
        nmBAL.nm_institute_id = Convert.ToInt16(Request.QueryString["unikhjn"].ToString());

        notice_master_DAL nmDAL = new notice_master_DAL();
        DataSet ds = nmDAL.notice_master_edit_data_instituteid(nmBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            rptsubjectfill.DataSource = ds;
            rptsubjectfill.DataBind();
        }
        else
        {
            rptsubjectfill.DataSource = null;
            rptsubjectfill.DataBind();
        }
    }
    void insitute_data_fill_notice_menu()
    {
        student_institute_link_BAL sdlBAL = new student_institute_link_BAL();
        sdlBAL.sil_verification_status = "1";
        sdlBAL.sil_stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_institute_link_DAL sdlDAL = new student_institute_link_DAL();
        DataSet ds = sdlDAL.student_institute_link_data_fill_verification_state_studant_data_show_institute(sdlBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            noticeinstitute.DataSource = ds;
            noticeinstitute.DataBind();
        }
        else
        {
            noticeinstitute.DataSource = null;
            noticeinstitute.DataBind();
        }

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["clientlogin"] != null)
            {

                logoutdiv.Visible = true;
                logindiv.Visible = false;
                //lblaboutus.Visible = false;
                homeli.Visible = false;
                fill_profile_data();
                insitute_data_fill_notice_menu(); 
                notice_data_fill_instituteid_rpt();
            }
            else
            {
                Notice.Visible = false;
                insituteadd.Visible = false;
                instituteyour.Visible = false;
                Response.Redirect("log_in.aspx");
            }
        }
    }
    public class WebClientWithTimeout : WebClient
    {
        protected override WebRequest GetWebRequest(Uri address)
        {
            WebRequest wr = base.GetWebRequest(address);
            wr.Timeout = 5000; // timeout in milliseconds (ms)
            return wr;
        }
    }
    string somestring;
    protected void rptsubjectfill_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        //if (e.CommandName == "viewdata")
        //{
        //    notice_master_BAL nmBAL = new notice_master_BAL();
        //    nmBAL.nm_id = Convert.ToInt16(e.CommandArgument.ToString());

        //    notice_master_DAL nmDAL = new notice_master_DAL();
        //    DataSet ds = nmDAL.notice_master_edit(nmBAL);
        //    if (ds.Tables[0].Rows.Count > 0)
        //    {
        //        Response.Write(ds.Tables[0].Rows[0]["nm_file_upload"].ToString());
        //        WebClient wc = new WebClientWithTimeout();
        //        somestring = wc.DownloadString(ds.Tables[0].Rows[0]["nm_file_upload"].ToString());
        //    }
        //}
    }
}