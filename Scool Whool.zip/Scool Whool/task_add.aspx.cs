﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class task_add : System.Web.UI.Page
{
    void student_task_reminder_data_fill_chackbox()
    {
        student_task_reminder_BAL strBAL = new student_task_reminder_BAL();
        strBAL.str_student_id = Convert.ToInt16(Session["clientlogin"].ToString());
        strBAL.str_status = "0";

        student_task_reminder_DAL strDAL = new student_task_reminder_DAL();
        DataSet ds = strDAL.student_task_reminder_data_fill_studant_id(strBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            rptfilltaskchack.DataSource = ds;
            rptfilltaskchack.DataBind();
        }
        else
        {
            rptfilltaskchack.DataSource = null;
            rptfilltaskchack.DataBind();
        }
    }
    void student_task_reminder_data_fill_chackbox_complittask()
    {
        student_task_reminder_BAL strBAL = new student_task_reminder_BAL();
        strBAL.str_student_id = Convert.ToInt16(Session["clientlogin"].ToString());
        strBAL.str_status = "1";

        student_task_reminder_DAL strDAL = new student_task_reminder_DAL();
        DataSet ds = strDAL.student_task_reminder_data_fill_studant_id(strBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            rptcomplittask.DataSource = ds;
            rptcomplittask.DataBind();
        }
        else
        {
            rptcomplittask.DataSource = null;
            rptcomplittask.DataBind();
        }
    }
    void fill_profile_data()
    {
        student_details_BAL sdBAL = new student_details_BAL();
        sdBAL.stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_details_DAL sdDAL = new student_details_DAL();
        DataSet ds = sdDAL.student_details_edit(sdBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            lbluserName.InnerText = ds.Tables[0].Rows[0]["stud_first_name"].ToString();
        }
    }
    void insitute_data_fill_notice_menu()
    {
        student_institute_link_BAL sdlBAL = new student_institute_link_BAL();
        sdlBAL.sil_verification_status = "1";
        sdlBAL.sil_stud_id = Convert.ToInt16(Session["clientlogin"].ToString());

        student_institute_link_DAL sdlDAL = new student_institute_link_DAL();
        DataSet ds = sdlDAL.student_institute_link_data_fill_verification_state_studant_data_show_institute(sdlBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            noticeinstitute.DataSource = ds;
            noticeinstitute.DataBind();
        }
        else
        {
            noticeinstitute.DataSource = null;
            noticeinstitute.DataBind();
        }

    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["clientlogin"] != null)
            {
                logoutdiv.Visible = true;
                logindiv.Visible = false;
                insitute_data_fill_notice_menu();
                //lblaboutus.Visible = false;
                homeli.Visible = false;
                student_task_reminder_data_fill_chackbox();
                student_task_reminder_data_fill_chackbox_complittask(); 
                fill_profile_data();
            }
            else
            {
                Response.Redirect("log_in.aspx");
            }
        }
    }
    protected void btntaskadd_Click(object sender, EventArgs e)
    {
        student_task_reminder_BAL strBAL = new student_task_reminder_BAL();
        strBAL.str_student_id = Convert.ToInt16(Session["clientlogin"].ToString());
        strBAL.str_task = txttaskadd.Text;
        strBAL.str_status = "0";
        strBAL.str_insdt = System.DateTime.Now;
        strBAL.str_insrid = Convert.ToInt16(Session["clientlogin"].ToString());
        strBAL.str_logdt = System.DateTime.Now;
        strBAL.str_logrid = Convert.ToInt16(Session["clientlogin"].ToString());

        student_task_reminder_DAL strDAL = new student_task_reminder_DAL();
        String val = strDAL.student_task_reminder_insert(strBAL);
        if (val != null)
        {
            Response.Write("<script>alert('Task Inserted');window.location.href='task_add.aspx';</script>");

        }

    }


    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
        foreach (RepeaterItem ri in rptfilltaskchack.Items)
        {
            CheckBox CheckBoxInRepeater = ri.FindControl("CheckBox1") as CheckBox;
            HiddenField hfvalue = ri.FindControl("hfstid") as HiddenField;
            if (CheckBoxInRepeater.Checked)
            {
                student_task_reminder_BAL strBAL = new student_task_reminder_BAL();
                strBAL.str_status = "1";
                strBAL.str_id = Convert.ToInt16(hfvalue.Value);

                student_task_reminder_DAL strDAL = new student_task_reminder_DAL();
                string val = strDAL.student_task_reminder_data_update(strBAL);
                if (val != null)
                {
                    Response.Write("<script>alert('Your Task Is complited.');window.location.href='task_add.aspx';</script>");
                }
            }
        }
    }
    protected void rptcomplittask_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "btndelettask")
        {
            student_task_reminder_BAL strBAL = new student_task_reminder_BAL();
            strBAL.str_id = Convert.ToInt16(e.CommandArgument.ToString());

            student_task_reminder_DAL strDAL = new student_task_reminder_DAL();
            string val = strDAL.student_task_reminder_data_delete(strBAL);
            if (val != null)
            {
                Response.Write("<script>alert('Your Task Is Deleted.');window.location.href='task_add.aspx';</script>");
            }
        }
    }
}