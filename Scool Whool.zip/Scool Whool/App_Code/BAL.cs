﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class country_master_BAL
{
    public int country_id { get; set; }
    public string country_name { get; set; }
    public string country_insdt { get; set; }
    public int country_insrid { get; set; }
    public string country_logdt { get; set; }
    public int country_logrid { get; set; }
}
public class state_master_BAL
{
    public int state_id { get; set; }
    public int state_country_id { get; set; }
    public string state_name { get; set; }
    public string state_insdt { get; set; }
    public int state_insrid { get; set; }
    public string state_logdt { get; set; }
    public int state_logrid { get; set; }
}
public class distric_master_BAL
{
    public int distric_id { get; set; }
    public int distric_state_id { get; set; }
    public string distric_name { get; set; }
    public string distric_insdt { get; set; }
    public int distric_insrid { get; set; }
    public string distric_logdt { get; set; }
    public int distric_logrid { get; set; }
}
public class taluka_master_BAL
{
    public int taluka_id { get; set; }
    public int taluka_distric_id { get; set; }
    public string taluka_name { get; set; }
    public string taluka_insdt { get; set; }
    public int taluka_insrid { get; set; }
    public string taluka_logdt { get; set; }
    public int taluka_logrid { get; set; }
}

public class admin_user_masterBAL
{
    public int aum_id { get; set; }
    public string aum_fullname { get; set; }
    public string aum_gender { get; set; }
    public string aum_contactno { get; set; }
    public string aum_email { get; set; }
    public string aum_password { get; set; }
    public int aum_user_role { get; set; }
    public int aum_status { get; set; }
    public DateTime aum_insdt { get; set; }
    public int aum_insrid { get; set; }
    public DateTime aum_logdt { get; set; }
    public int aum_logrid { get; set; }
    public DateTime aum_last_login { get; set; }
    public DateTime aum_last_logout { get; set; }
}
public class standard_masterBAL : institute_details_BAL
{
    public int standard_id { get; set; }
    public string standard_name { get; set; }
    public DateTime standard_insdt { get; set; }
    public string standard_insip { get; set; }
    public int standard_insrid { get; set; }
    public DateTime standard_logdt { get; set; }
    public string standard_logip { get; set; }
    public int standard_logrid { get; set; }
    public string institute_video_fill_value { get; set; }
}
public class subject_masterBAL : third_topic_masterBAL
{
    public int subject_id { get; set; }
    public string subject_name { get; set; }
    public string subject_image { get; set; }
    public DateTime subject_insdt { get; set; }
    public string subject_insip { get; set; }
    public int subject_insrid { get; set; }
    public DateTime subject_logdt { get; set; }
    public string subject_logip { get; set; }
    public int subject_logrid { get; set; }
    public int filtertopic { get; set; }

}
public class topic_masterBAL
{
    public int topic_id { get; set; }
    public int topic_subject_id { get; set; }
    public string topic_name { get; set; }
    public DateTime topic_insdt { get; set; }
    public string topic_insip { get; set; }
    public int topic_insrid { get; set; }
    public DateTime topic_logdt { get; set; }
    public string topic_logip { get; set; }
    public int topic_logrid { get; set; }
}
public class sub_topic_masterBAL : topic_masterBAL
{
    public int sub_topic_id { get; set; }
    public int sub_topic_topic_id { get; set; }
    public string sub_topic_name { get; set; }
    public DateTime sub_topic_insdt { get; set; }
    public string sub_topic_insip { get; set; }
    public int sub_topic_insrid { get; set; }
    public DateTime sub_topic_logdt { get; set; }
    public string sub_topic_logip { get; set; }
    public int sub_topic_logrid { get; set; }
}
public class third_topic_masterBAL :sub_topic_masterBAL
{
    public int third_topic_id { get; set; }
    public int third_topic_sub_topic_id { get; set; }
    public string third_topic_name { get; set; }
    public DateTime third_topic_insdt { get; set; }
    public string third_topic_insip { get; set; }
    public int third_topic_insrid { get; set; }
    public DateTime third_topic_logdt { get; set; }
    public string third_topic_logip { get; set; }
    public int third_topic_logrid { get; set; }
}
public class board_masterBAL
{
    public int board_id { get; set; }
    public string board_name { get; set; }
    public DateTime board_insdt { get; set; }
    public string board_insip { get; set; }
    public int board_insrid { get; set; }
    public DateTime board_logdt { get; set; }
    public string board_logip { get; set; }
    public int board_logrid { get; set; }
}
public class institute_type_masterBAL
{
    public int institute_type_id { get; set; }
    public string institute_type_name { get; set; }
    public DateTime institute_type_insdt { get; set; }
    public string institute_type_insip { get; set; }
    public int institute_type_insrid { get; set; }
    public DateTime institute_type_logdt { get; set; }
    public string institute_type_logip { get; set; }
    public int institute_type_logrid { get; set; }
}
public class language_masterBAL
{
    public int language_id { get; set; }
    public string language_name { get; set; }
    public DateTime language_insdt { get; set; }
    public string language_insip { get; set; }
    public int language_insrid { get; set; }
    public DateTime language_logdt { get; set; }
    public string language_logip { get; set; }
    public int language_logrid { get; set; }
}
public class medium_masterBAL
{
    public int medium_id { get; set; }
    public string medium_name { get; set; }
    public DateTime medium_insdt { get; set; }
    public string medium_insip { get; set; }
    public int medium_insrid { get; set; }
    public DateTime medium_logdt { get; set; }
    public string medium_logip { get; set; }
    public int medium_logrid { get; set; }
}
public class video_masterBAL
{
    public int video_id { get; set; }
    public int video_third_topic_id { get; set; }
    public int video_institute_id { get; set; }
    public string video_link { get; set; }
    public DateTime video_insdt { get; set; }
    public string video_insip { get; set; }
    public int video_insrid { get; set; }
    public DateTime video_logdt { get; set; }
    public string video_logip { get; set; }
    public int video_logrid { get; set; }
}
public class video_other_information_masterBAL
{
    public int voim_id { get; set; }
    public int voim_video_id { get; set; }
    public string voim_video_title { get; set; }
    public string voim_description { get; set; }
    public string voim_metatags { get; set; }
    public DateTime voim_insdt { get; set; }
    public string voim_insip { get; set; }
    public int voim_insrid { get; set; }
    public DateTime voim_logdt { get; set; }
    public string voim_logip { get; set; }
    public int voim_logrid { get; set; }
}

//institute details fill
public class institute_details_BAL : subject_masterBAL
{
    public int id_id { get; set; }
    public string id_institute_code { get; set; }
    public int id_type { get; set; }
    public string id_name { get; set; }
    public string id_mobile_no { get; set; }
    public string id_email { get; set; }
    public string id_email_verification { get; set; }
    public string id_website { get; set; }
    public string id_website_verification { get; set; }
    public string id_address_line_1 { get; set; }
    public string id_address_line_2 { get; set; }
    public string id_landmark { get; set; }
    public int id_state_id { get; set; }
    public int id_district_id { get; set; }
    public int id_tahesil_id { get; set; }
    public string id_password { get; set; }
    public string id_verification_status { get; set; }
    public DateTime id_date_of_registration { get; set; }
    public DateTime id_logdt { get; set; }
    public int id_logrid { get; set; }
    public string institute_total_value_find { get;set; }
}
public class student_institute_link_BAL
{
    public int sil_id { get; set; }
    public string sil_id_id { get; set; }
    public int sil_stud_id { get; set; }
    public string sil_verification_status { get; set; }
    public string institute_code_no { get; set; }


}
 
//video data fill
public class video_master_BAL
{
    public int video_id { get; set; }
    public int video_institute_id { get; set; }
    public int video_standard_id { get; set; }
    public int video_third_topic_id { get; set; }
    public int video_medium_id { get; set; }
    public int video_board_id { get; set; }
    public int video_language_id { get; set; }
    public string video_link { get; set; }
    public string video_title { get; set; }
    public string video_description { get; set; }
    public string video_thumbnail_image { get; set; }
    public string video_meta_tag { get; set; }
    public DateTime video_insdt { get; set; }
    public string video_insip { get; set; }
    public int video_insrid { get; set; }
    public DateTime video_logdt { get; set; }
    public string video_logip { get; set; }
    public int video_logrid { get; set; }


}
public class student_details_BAL : institute_details_BAL
{
    public int stud_id { get; set; }
    public string stud_first_name { get; set; }
    public string stud_middle_name { get; set; }
    public string stud_last_name { get; set; }
    public string stud_gender { get; set; }
    public string stud_mobile_no { get; set; }
    public string stud_dob { get; set; }
    public string stud_email { get; set; }
    public int stud_std_id { get; set; }
    public string stud_password { get; set; }
    public string stud_status { get; set; }
    public DateTime stud_insdt { get; set; }
    public string stud_insip { get; set; }
    public int stud_insrid { get; set; }
    public DateTime stud_logdt { get; set; }
    public string stud_logip { get; set; }
    public int stud_logrid { get; set; }
    public string studant_total_value { get; set; }
}

//notish
public class notice_master_BAL
{
    public int nm_id { get; set; }
    public int nm_institute_id { get; set; }
    public string nm_title { get; set; }
    public string nm_description { get; set; }
    public string nm_file_upload { get; set; }
    public DateTime nm_effective_date { get; set; }
    public DateTime nm_ineffective_date { get; set; }
    public string nm_status { get; set; }
    public DateTime nm_insdt { get; set; }
    public int nm_insrid { get; set; }
    public DateTime nm_logdt { get; set; }
    public int nm_logrid { get; set; }



}

//task
public class student_task_reminder_BAL
{
    public int str_id { get; set; }
    public int str_student_id { get; set; }
    public string str_task { get; set; }
    public string str_status { get; set; }
    public DateTime str_insdt { get; set; }
    public int str_insrid { get; set; }
    public DateTime str_logdt { get; set; }
    public int str_logrid { get; set; }

}
