﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

public class connection
{
    public MySqlCommand cmd;
    public MySqlConnection con;
    public MySqlDataAdapter da;
    public DataSet ds;

    public void mycon()
    {
        con = new MySqlConnection(ConfigurationManager.ConnectionStrings["dbcon"].ToString());
        con.Open();
    }

}

//address data

public class alladdress_insert_data_DAL : connection
{
    public int country_data_insert(country_master_BAL cmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_country", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("_country_id", cmBAL.country_id);
        cmd.Parameters.AddWithValue("_country_name", cmBAL.country_name);
        cmd.Parameters.AddWithValue("_country_insdt", cmBAL.country_insdt);
        cmd.Parameters.AddWithValue("_country_insrid", cmBAL.country_insrid);
        cmd.Parameters.AddWithValue("_country_logdt", cmBAL.country_logdt);
        cmd.Parameters.AddWithValue("_country_logrid", cmBAL.country_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        con.Close();
        con.Dispose();
        return id;
    }

    public int state_data_insert(state_master_BAL stBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_state", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("_state_id", stBAL.state_id);
        cmd.Parameters.AddWithValue("_state_country_id", stBAL.state_country_id);
        cmd.Parameters.AddWithValue("_state_name", stBAL.state_name);
        cmd.Parameters.AddWithValue("_state_insdt", stBAL.state_insdt);
        cmd.Parameters.AddWithValue("_state_insrid", stBAL.state_insrid);
        cmd.Parameters.AddWithValue("_state_logdt", stBAL.state_logdt);
        cmd.Parameters.AddWithValue("_state_logrid", stBAL.state_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        con.Close();
        con.Dispose();
        return id;
    }
    public int distric_data_insert(distric_master_BAL dmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_distric", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("_distric_id", dmBAL.distric_id);
        cmd.Parameters.AddWithValue("_distric_state_id", dmBAL.distric_state_id);
        cmd.Parameters.AddWithValue("_distric_name", dmBAL.distric_name);
        cmd.Parameters.AddWithValue("_distric_insdt", dmBAL.distric_insdt);
        cmd.Parameters.AddWithValue("_distric_insrid", dmBAL.distric_insrid);
        cmd.Parameters.AddWithValue("_distric_logdt", dmBAL.distric_logdt);
        cmd.Parameters.AddWithValue("_distric_logrid", dmBAL.distric_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        con.Close();
        con.Dispose();
        return id;
    }
    public int taluka_data_insert(taluka_master_BAL dmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_taluka", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("_taluka_id", dmBAL.taluka_id);
        cmd.Parameters.AddWithValue("_taluka_distric_id", dmBAL.taluka_distric_id);
        cmd.Parameters.AddWithValue("_taluka_name", dmBAL.taluka_name);
        cmd.Parameters.AddWithValue("_taluka_insdt", dmBAL.taluka_insdt);
        cmd.Parameters.AddWithValue("_taluka_insrid", dmBAL.taluka_insrid);
        cmd.Parameters.AddWithValue("_taluka_logdt", dmBAL.taluka_logdt);
        cmd.Parameters.AddWithValue("_taluka_logrid", dmBAL.taluka_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        con.Close();
        con.Dispose();
        return id;
    }
}
public class alladdress_edit_data_DAL : connection
{
    public DataSet country_data_edit(country_master_BAL cmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from country_master where country_id=@cid", con);
        cmd.Parameters.AddWithValue("@cid", cmBAL.country_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    //public DataSet preference_data_edit(preference_detail_BAL cmBAL)
    //{
    //    mycon();
    //    cmd = new MySqlCommand("select * from preference_detail where pd_id=@pid", con);
    //    cmd.Parameters.AddWithValue("@pid", cmBAL.pd_id);
    //    da = new MySqlDataAdapter(cmd);
    //    ds = new DataSet();
    //    da.Fill(ds);
    //    con.Close();
    //    con.Dispose();
    //    return ds;
    //}
    public DataSet state_data_edit(state_master_BAL cmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from country_state_view where state_id=@scid", con);
        cmd.Parameters.AddWithValue("@scid", cmBAL.state_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet distric_data_edit(distric_master_BAL dsBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from state_and_distric_data_view where distric_id=@dsid", con);
        cmd.Parameters.AddWithValue("@dsid", dsBAL.distric_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet taluka_data_edit(taluka_master_BAL tdBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from distric_taluka_data_view where taluka_id=@tdid", con);
        cmd.Parameters.AddWithValue("@tdid", tdBAL.taluka_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

}
public class alladdress_get_data_DAL : connection
{
    public DataSet country_data()
    {
        mycon();
        cmd = new MySqlCommand("select * from country_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet preference_data()
    {
        mycon();
        cmd = new MySqlCommand("select * from preference_detail", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet state_data()
    {
        mycon();
        cmd = new MySqlCommand("select * from state_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet distric_data()
    {
        mycon();
        cmd = new MySqlCommand("select * from distric_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet taluka_data()
    {
        mycon();
        cmd = new MySqlCommand("select * from taluka_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet city_village_data()
    {
        mycon();
        cmd = new MySqlCommand("select * from  city_village_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet country_and_state_data(state_master_BAL cmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from country_state_view where state_country_id=@scid", con);
        cmd.Parameters.AddWithValue("@scid", cmBAL.state_country_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet state_and_distric_data(distric_master_BAL dsBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from state_and_distric_data_view where distric_state_id=@dsid", con);
        cmd.Parameters.AddWithValue("@dsid", dsBAL.distric_state_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet distric_and_taluka_data(taluka_master_BAL tdBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from distric_taluka_data_view where taluka_distric_id=@tdid", con);
        cmd.Parameters.AddWithValue("@tdid", tdBAL.taluka_distric_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

}
public class admin_user_masterDAL : connection
{
    public int admin_user_master_addupdate(admin_user_masterBAL aumBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_admin_user_master_master", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_aum_id", aumBAL.aum_id);
        cmd.Parameters.AddWithValue("@_aum_fullname", aumBAL.aum_fullname);
        cmd.Parameters.AddWithValue("@_aum_gender", aumBAL.aum_gender);
        cmd.Parameters.AddWithValue("@_aum_contactno", aumBAL.aum_contactno);
        cmd.Parameters.AddWithValue("@_aum_email", aumBAL.aum_email);
        cmd.Parameters.AddWithValue("@_aum_password", aumBAL.aum_password);
        cmd.Parameters.AddWithValue("@_aum_user_role", aumBAL.aum_user_role);
        cmd.Parameters.AddWithValue("@_aum_status", aumBAL.aum_status);
        cmd.Parameters.AddWithValue("@_aum_insdt", aumBAL.aum_insdt);
        cmd.Parameters.AddWithValue("@_aum_insrid", aumBAL.aum_insrid);
        cmd.Parameters.AddWithValue("@_aum_logdt", aumBAL.aum_logdt);
        cmd.Parameters.AddWithValue("@_aum_logrid", aumBAL.aum_logrid);
        cmd.Parameters.AddWithValue("@_aum_last_login", aumBAL.aum_last_login);
        cmd.Parameters.AddWithValue("@_aum_last_logout", aumBAL.aum_last_logout);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        return id;
    }
    public string admin_user_login(admin_user_masterBAL aumBAL)
    {
        mycon();
        cmd = new MySqlCommand("admin_user_login", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_aum_contactno", aumBAL.aum_contactno);
        cmd.Parameters.AddWithValue("@_aum_password", aumBAL.aum_password);

        MySqlParameter retdes = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        retdes.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(retdes);

        MySqlParameter retid = new MySqlParameter("@_admin_user_id", SqlDbType.Int);
        retid.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(retid);

        MySqlParameter retrole = new MySqlParameter("@_admin_user_role", SqlDbType.Int);
        retrole.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(retrole);

        cmd.ExecuteNonQuery();

        int retdesval = (int)retdes.Value;
        int retidval = (int)retid.Value;
        int retroleval = (int)retrole.Value;

        return "" + retdesval + "|" + retidval + "|" + retroleval + "";
    }
    public int admin_user_logout(admin_user_masterBAL aumBAL)
    {
        mycon();
        cmd = new MySqlCommand("update admin_user_master set aum_last_logout=" + System.DateTime.Now.ToString("yyyy-MM-dd") + " where aum_id=@aid", con);
        cmd.Parameters.AddWithValue("@aid", aumBAL.aum_id);
        cmd.ExecuteNonQuery();
        return 1;
    }
}

public class standard_masterDAL : connection
{
    public int standard_master_add_update(standard_masterBAL stdmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_standard_master", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_standard_id", stdmBAL.standard_id);
        cmd.Parameters.AddWithValue("@_standard_name", stdmBAL.standard_name);
        cmd.Parameters.AddWithValue("@_standard_insdt", stdmBAL.standard_insdt);
        cmd.Parameters.AddWithValue("@_standard_insip", stdmBAL.standard_insip);
        cmd.Parameters.AddWithValue("@_standard_insrid", stdmBAL.standard_insrid);
        cmd.Parameters.AddWithValue("@_standard_logdt", stdmBAL.standard_logdt);
        cmd.Parameters.AddWithValue("@_standard_logip", stdmBAL.standard_logip);
        cmd.Parameters.AddWithValue("@_standard_logrid", stdmBAL.standard_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        return id;
    }
    public DataSet get_all_standard()
    {
        mycon();
        cmd = new MySqlCommand("select * from standard_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet get_single_standard_detail(standard_masterBAL stdmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from standard_master where standard_id=@stdid", con);
        cmd.Parameters.AddWithValue("@stdid", stdmBAL.standard_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }


}

public class subject_masterDAL : connection
{
    public int subject_master_add_update(subject_masterBAL stdmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_subject_master", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_subject_id", stdmBAL.subject_id);
        cmd.Parameters.AddWithValue("@_subject_name", stdmBAL.subject_name);
        cmd.Parameters.AddWithValue("@_subject_image", stdmBAL.subject_image);
        cmd.Parameters.AddWithValue("@_subject_insdt", stdmBAL.subject_insdt);
        cmd.Parameters.AddWithValue("@_subject_insip", stdmBAL.subject_insip);
        cmd.Parameters.AddWithValue("@_subject_insrid", stdmBAL.subject_insrid);
        cmd.Parameters.AddWithValue("@_subject_logdt", stdmBAL.subject_logdt);
        cmd.Parameters.AddWithValue("@_subject_logip", stdmBAL.subject_logip);
        cmd.Parameters.AddWithValue("@_subject_logrid", stdmBAL.subject_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        return id;
    }
    public DataSet get_all_subject()
    {
        mycon();
        cmd = new MySqlCommand("select * from subject_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_single_subject_detail(subject_masterBAL stdmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from subject_master where subject_id=@stdid", con);
        cmd.Parameters.AddWithValue("@stdid", stdmBAL.subject_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

}

public class institute_data_fill_and_fillter : connection
{
    public DataSet video_master_data_fill_insitute_page(standard_masterBAL stdmBAL)
    {
        mycon();


        if (stdmBAL.institute_video_fill_value == "0")
        {
            cmd = new MySqlCommand("Select * from video_all_data_get where id_id=@idid", con);
            //cmd = new MySqlCommand("SELECT * FROM video_all_data_get where subject_id=@sbj", con);

        }
        if (stdmBAL.institute_video_fill_value == "1")
        {
            cmd = new MySqlCommand("Select * from video_all_data_get where id_id=@idid and standard_id=@sid", con);
            cmd.Parameters.AddWithValue("@sid", stdmBAL.standard_id);
        }
        if (stdmBAL.institute_video_fill_value == "2")
        {
            cmd = new MySqlCommand("Select * from video_all_data_get where id_id=@idid and subject_id=@sjid", con);
            cmd.Parameters.AddWithValue("@sjid", stdmBAL.subject_id);
        }
        if (stdmBAL.institute_video_fill_value == "3")
        {
            cmd = new MySqlCommand("Select * from video_all_data_get where id_id=@idid and subject_id=@sjid and topic_id=@tid", con);
            cmd.Parameters.AddWithValue("@sjid", stdmBAL.subject_id);
            cmd.Parameters.AddWithValue("@tid", stdmBAL.topic_id);
        }
        if (stdmBAL.institute_video_fill_value == "4")
        {
            cmd = new MySqlCommand("Select * from video_all_data_get where id_id=@idid and subject_id=@sjid and topic_id=@tid and sub_topic_id=@subtid", con);
            cmd.Parameters.AddWithValue("@sjid", stdmBAL.subject_id);
            cmd.Parameters.AddWithValue("@tid", stdmBAL.topic_id);
            cmd.Parameters.AddWithValue("@subtid", stdmBAL.sub_topic_id);
        }
        if (stdmBAL.institute_video_fill_value == "5")
        {
            cmd = new MySqlCommand("Select * from video_all_data_get where id_id=@idid and subject_id=@sjid and topic_id=@tid and sub_topic_id=@subtid and third_topic_id=@ttid", con);
            cmd.Parameters.AddWithValue("@sjid", stdmBAL.subject_id);
            cmd.Parameters.AddWithValue("@tid", stdmBAL.topic_id);
            cmd.Parameters.AddWithValue("@subtid", stdmBAL.sub_topic_id);
            cmd.Parameters.AddWithValue("@ttid", stdmBAL.third_topic_id);
        }
        cmd.Parameters.AddWithValue("@idid", stdmBAL.id_id);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
}
public class fillter_topic_video : connection
{
    public DataSet video_master_data_fill_subjectid_video_data(subject_masterBAL stdmBAL)
    {
        mycon();
        if (stdmBAL.filtertopic == 0)
        {
            cmd = new MySqlCommand("SELECT * FROM video_all_data_get where subject_id=@sbj", con);

        }
        if (stdmBAL.filtertopic == 1)
        {
            cmd = new MySqlCommand("SELECT * FROM video_all_data_get where subject_id=@sbj and topic_id=@tpm", con);
            cmd.Parameters.AddWithValue("@tpm", stdmBAL.topic_id);

        }
        if (stdmBAL.filtertopic == 2)
        {
            cmd = new MySqlCommand("SELECT * FROM video_all_data_get where subject_id=@sbj and sub_topic_id=@stpm", con);
            cmd.Parameters.AddWithValue("@stpm", stdmBAL.sub_topic_id);
        }
        if (stdmBAL.filtertopic == 3)
        {
            cmd = new MySqlCommand("SELECT * FROM video_all_data_get where subject_id=@sbj and third_topic_id=@ttpm", con);
            cmd.Parameters.AddWithValue("@ttpm", stdmBAL.third_topic_id);
        }
        cmd.Parameters.AddWithValue("@sbj", stdmBAL.subject_id);

        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
}

public class medium_masterDAL : connection
{
    public int medium_master_add_update(medium_masterBAL stdmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_medium_master", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_medium_id", stdmBAL.medium_id);
        cmd.Parameters.AddWithValue("@_medium_name", stdmBAL.medium_name);
        cmd.Parameters.AddWithValue("@_medium_insdt", stdmBAL.medium_insdt);
        cmd.Parameters.AddWithValue("@_medium_insip", stdmBAL.medium_insip);
        cmd.Parameters.AddWithValue("@_medium_insrid", stdmBAL.medium_insrid);
        cmd.Parameters.AddWithValue("@_medium_logdt", stdmBAL.medium_logdt);
        cmd.Parameters.AddWithValue("@_medium_logip", stdmBAL.medium_logip);
        cmd.Parameters.AddWithValue("@_medium_logrid", stdmBAL.medium_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        return id;
    }
    public DataSet get_all_medium()
    {
        mycon();
        cmd = new MySqlCommand("select * from medium_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_single_medium_detail(medium_masterBAL stdmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from medium_master where medium_id=@stdid", con);
        cmd.Parameters.AddWithValue("@stdid", stdmBAL.medium_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
}

public class board_masterDAL : connection
{
    public int board_master_add_update(board_masterBAL stdmBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_board_master", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_board_id", stdmBAL.board_id);
        cmd.Parameters.AddWithValue("@_board_name", stdmBAL.board_name);
        cmd.Parameters.AddWithValue("@_board_insdt", stdmBAL.board_insdt);
        cmd.Parameters.AddWithValue("@_board_insip", stdmBAL.board_insip);
        cmd.Parameters.AddWithValue("@_board_insrid", stdmBAL.board_insrid);
        cmd.Parameters.AddWithValue("@_board_logdt", stdmBAL.board_logdt);
        cmd.Parameters.AddWithValue("@_board_logip", stdmBAL.board_logip);
        cmd.Parameters.AddWithValue("@_board_logrid", stdmBAL.board_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        return id;
    }
    public DataSet get_all_board()
    {
        mycon();
        cmd = new MySqlCommand("select * from board_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_single_board_detail(board_masterBAL stdmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from board_master where board_id=@stdid", con);
        cmd.Parameters.AddWithValue("@stdid", stdmBAL.board_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
}

public class language_masterDAL : connection
{
    public int language_master_add_update(language_masterBAL lngBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_language_master", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_language_id", lngBAL.language_id);
        cmd.Parameters.AddWithValue("@_language_name", lngBAL.language_name);
        cmd.Parameters.AddWithValue("@_language_insdt", lngBAL.language_insdt);
        cmd.Parameters.AddWithValue("@_language_insip", lngBAL.language_insip);
        cmd.Parameters.AddWithValue("@_language_insrid", lngBAL.language_insrid);
        cmd.Parameters.AddWithValue("@_language_logdt", lngBAL.language_logdt);
        cmd.Parameters.AddWithValue("@_language_logip", lngBAL.language_logip);
        cmd.Parameters.AddWithValue("@_language_logrid", lngBAL.language_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        return id;
    }
    public DataSet get_all_language()
    {
        mycon();
        cmd = new MySqlCommand("select * from language_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_single_language_detail(language_masterBAL lngBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from language_master where language_id=@stdid", con);
        cmd.Parameters.AddWithValue("@stdid", lngBAL.language_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
}

public class topic_masterDAL : connection
{
    public int topic_master_add_update(topic_masterBAL tpBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_topic_master", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_topic_id", tpBAL.topic_id);
        cmd.Parameters.AddWithValue("@_topic_subject_id", tpBAL.topic_subject_id);
        cmd.Parameters.AddWithValue("@_topic_name", tpBAL.topic_name);
        cmd.Parameters.AddWithValue("@_topic_insdt", tpBAL.topic_insdt);
        cmd.Parameters.AddWithValue("@_topic_insip", tpBAL.topic_insip);
        cmd.Parameters.AddWithValue("@_topic_insrid", tpBAL.topic_insrid);
        cmd.Parameters.AddWithValue("@_topic_logdt", tpBAL.topic_logdt);
        cmd.Parameters.AddWithValue("@_topic_logip", tpBAL.topic_logip);
        cmd.Parameters.AddWithValue("@_topic_logrid", tpBAL.topic_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        return id;
    }
    public DataSet get_all_topic()
    {
        mycon();
        cmd = new MySqlCommand("select * from get_topic_details", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet topic_drop_down_fill(topic_masterBAL tpmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from get_topic_details where topic_subject_id=@tpsbjid", con);
        cmd.Parameters.AddWithValue("@tpsbjid", tpmBAL.topic_subject_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_single_topic_detail(topic_masterBAL tpBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from get_topic_details where topic_id=@stdid", con);
        cmd.Parameters.AddWithValue("@stdid", tpBAL.topic_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

}
public class sub_topic_masterDAL : connection
{
    public int sub_topic_master_add_update(sub_topic_masterBAL sbtpBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_sub_topic_master", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_sub_topic_id", sbtpBAL.sub_topic_id);
        cmd.Parameters.AddWithValue("@_sub_topic_topic_id", sbtpBAL.sub_topic_topic_id);
        cmd.Parameters.AddWithValue("@_sub_topic_name", sbtpBAL.sub_topic_name);
        cmd.Parameters.AddWithValue("@_sub_topic_insdt", sbtpBAL.sub_topic_insdt);
        cmd.Parameters.AddWithValue("@_sub_topic_insip", sbtpBAL.sub_topic_insip);
        cmd.Parameters.AddWithValue("@_sub_topic_insrid", sbtpBAL.sub_topic_insrid);
        cmd.Parameters.AddWithValue("@_sub_topic_logdt", sbtpBAL.sub_topic_logdt);
        cmd.Parameters.AddWithValue("@_sub_topic_logip", sbtpBAL.sub_topic_logip);
        cmd.Parameters.AddWithValue("@_sub_topic_logrid", sbtpBAL.sub_topic_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        return id;
    }
    public DataSet get_all_sub_topic()
    {
        mycon();
        cmd = new MySqlCommand("select * from get_sub_topic_details", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet get_sub_topic_for_dropdownfill(sub_topic_masterBAL stpBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from sub_topic_master where sub_topic_topic_id=@sbtpid", con);
        cmd.Parameters.AddWithValue("@sbtpid", stpBAL.sub_topic_topic_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_single_sub_topic_detail(sub_topic_masterBAL sbtpBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from get_sub_topic_details where sub_topic_id=@stdid", con);
        cmd.Parameters.AddWithValue("@stdid", sbtpBAL.sub_topic_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
}
public class third_topic_masterDAL : connection
{
    public int third_topic_master_add_update(third_topic_masterBAL thtpBAL)
    {
        mycon();
        cmd = new MySqlCommand("add_update_third_topic", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_third_topic_id", thtpBAL.third_topic_id);
        cmd.Parameters.AddWithValue("@_third_topic_sub_topic_id", thtpBAL.third_topic_sub_topic_id);
        cmd.Parameters.AddWithValue("@_third_topic_name", thtpBAL.third_topic_name);
        cmd.Parameters.AddWithValue("@_third_topic_insdt", thtpBAL.third_topic_insdt);
        cmd.Parameters.AddWithValue("@_third_topic_insip", thtpBAL.third_topic_insip);
        cmd.Parameters.AddWithValue("@_third_topic_insrid", thtpBAL.third_topic_insrid);
        cmd.Parameters.AddWithValue("@_third_topic_logdt", thtpBAL.third_topic_logdt);
        cmd.Parameters.AddWithValue("@_third_topic_logip", thtpBAL.third_topic_logip);
        cmd.Parameters.AddWithValue("@_third_topic_logrid", thtpBAL.third_topic_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        con.Close();
        con.Dispose();
        return id;
    }
    public DataSet get_all_third_topic()
    {
        mycon();
        cmd = new MySqlCommand("select * from get_third_topic_details", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet get_third_topic_for_dropdownfill(third_topic_masterBAL thtpBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from get_third_topic_details where third_topic_sub_topic_id=@sbtpid", con);
        cmd.Parameters.AddWithValue("@sbtpid", thtpBAL.third_topic_sub_topic_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet get_single_third_topic_detail(third_topic_masterBAL thtpBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from get_third_topic_details where third_topic_id=@thtpid", con);
        cmd.Parameters.AddWithValue("@thtpid", thtpBAL.third_topic_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
}

//institute detail data
public class institute_type_master_DAL : connection
{
    public int institute_type_master_insert(institute_type_masterBAL itmBAL)
    {
        mycon();
        cmd = new MySqlCommand("institute_type_add_update", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_institute_type_id", itmBAL.institute_type_id);
        cmd.Parameters.AddWithValue("@_institute_type_name", itmBAL.institute_type_name);
        cmd.Parameters.AddWithValue("@_institute_type_insdt", itmBAL.institute_type_insdt);
        cmd.Parameters.AddWithValue("@_institute_type_insip", itmBAL.institute_type_insip);
        cmd.Parameters.AddWithValue("@_institute_type_insrid", itmBAL.institute_type_insrid);
        cmd.Parameters.AddWithValue("@_institute_type_logdt", itmBAL.institute_type_logdt);
        cmd.Parameters.AddWithValue("@_institute_type_logip", itmBAL.institute_type_logip);
        cmd.Parameters.AddWithValue("@_institute_type_logrid", itmBAL.institute_type_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        con.Close();
        con.Dispose();
        return id;
    }
    public DataSet institute_type_master_data_fill()
    {
        mycon();
        cmd = new MySqlCommand("select * from institute_type_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet institute_type_master_edit(institute_type_masterBAL itmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from institute_type_master where institute_type_id=@itmid", con);
        cmd.Parameters.AddWithValue("@itmid", itmBAL.institute_type_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
}
public class institute_details_DAL : connection
{
    public int institute_details_insert(institute_details_BAL idBAL)
    {
        mycon();
        cmd = new MySqlCommand("institute_details_add_update", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_id_id", idBAL.id_id);
        cmd.Parameters.AddWithValue("@_id_institute_code", idBAL.id_institute_code);
        cmd.Parameters.AddWithValue("@_id_type", idBAL.id_type);
        cmd.Parameters.AddWithValue("@_id_name", idBAL.id_name);
        cmd.Parameters.AddWithValue("@_id_mobile_no", idBAL.id_mobile_no);
        cmd.Parameters.AddWithValue("@_id_email", idBAL.id_email);
        cmd.Parameters.AddWithValue("@_id_email_verification", idBAL.id_email_verification);
        cmd.Parameters.AddWithValue("@_id_website", idBAL.id_website);
        cmd.Parameters.AddWithValue("@_id_website_verification", idBAL.id_website_verification);
        cmd.Parameters.AddWithValue("@_id_address_line_1", idBAL.id_address_line_1);
        cmd.Parameters.AddWithValue("@_id_address_line_2", idBAL.id_address_line_2);
        cmd.Parameters.AddWithValue("@_id_landmark", idBAL.id_landmark);
        cmd.Parameters.AddWithValue("@_id_state_id", idBAL.id_state_id);
        cmd.Parameters.AddWithValue("@_id_district_id", idBAL.id_district_id);
        cmd.Parameters.AddWithValue("@_id_tahesil_id", idBAL.id_tahesil_id);
        cmd.Parameters.AddWithValue("@_id_password", idBAL.id_password);
        cmd.Parameters.AddWithValue("@_id_verification_status", idBAL.id_verification_status);
        cmd.Parameters.AddWithValue("@_id_date_of_registration", idBAL.id_date_of_registration);
        cmd.Parameters.AddWithValue("@_id_logdt", idBAL.id_logdt);
        cmd.Parameters.AddWithValue("@_id_logrid", idBAL.id_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        con.Close();
        con.Dispose();
        return id;
    }
    public DataSet institute_details_data_fill()
    {
        mycon();
        cmd = new MySqlCommand("select * from institute_and_institute_type_data_view", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet institute_details_data_fill_verification_states(institute_details_BAL idBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from institute_and_institute_type_data_view where id_verification_status=@st", con);
        cmd.Parameters.AddWithValue("@st", idBAL.id_verification_status);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    //public DataSet institute_details_data_fill_verification_states_(institute_details_BAL idBAL)
    //{
    //    mycon();
    //    cmd = new MySqlCommand("select * from institute_and_institute_type_data_view where id_verification_status=@st", con);
    //    cmd.Parameters.AddWithValue("@st", idBAL.id_verification_status);
    //    da = new MySqlDataAdapter(cmd);
    //    ds = new DataSet();
    //    da.Fill(ds);
    //    con.Close();
    //    con.Dispose();
    //    return ds;
    //}
    public DataSet institute_details_data_fill_chack_verirfication_institute_code(institute_details_BAL idBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from institute_details where id_mobile_no=@mon and id_verification_status=@st", con);
        cmd.Parameters.AddWithValue("@mon", idBAL.id_mobile_no);
        cmd.Parameters.AddWithValue("@st", idBAL.id_verification_status);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet institute_details_login_data_fill(institute_details_BAL idBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from institute_details where id_mobile_no=@imno and id_password=@ipass", con);
        cmd.Parameters.AddWithValue("@imno", idBAL.id_mobile_no);
        cmd.Parameters.AddWithValue("@ipass", idBAL.id_password);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public string institute_details_update_active_reject_data(institute_details_BAL idBAL)
    {
        mycon();
        cmd = new MySqlCommand("update institute_details set id_verification_status=@vs where id_id=@iid", con);
        cmd.Parameters.AddWithValue("@vs", idBAL.id_verification_status);
        cmd.Parameters.AddWithValue("@iid", idBAL.id_id);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
        return "Update";
    }

    public DataSet institute_details_data_edit(institute_details_BAL idBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from institute_and_institute_type_data_view where id_id=@iid", con);
        cmd.Parameters.AddWithValue("@iid", idBAL.id_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public int total_institute_data_fill(institute_details_BAL idBAL)
    {
        mycon();
        if (idBAL.institute_total_value_find == "0")
        {
            cmd = new MySqlCommand("select count(id_id) from institute_details", con);
        }
        if (idBAL.institute_total_value_find == "1")
        {
            cmd = new MySqlCommand("select count(id_id) from institute_details where id_verification_status=1", con);
        }
        if (idBAL.institute_total_value_find == "2")
        {
            cmd = new MySqlCommand("select count(id_id) from institute_details where id_verification_status=0", con);
        }
        if (idBAL.institute_total_value_find == "3")
        {
            cmd = new MySqlCommand("select count(id_id) from institute_details where id_verification_status=2", con);
        }
        
        int totalinstitute = Convert.ToInt16(cmd.ExecuteScalar().ToString());
        con.Close();
        con.Dispose();
        return totalinstitute;
    }
}
public class student_institute_link_DAL : connection
{
    public int student_institute_link_insert(student_institute_link_BAL sdlBAL)
    {
        mycon();
        cmd = new MySqlCommand("student_institute_link_add", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_sil_id", sdlBAL.sil_id);
        cmd.Parameters.AddWithValue("@_sil_id_id", sdlBAL.sil_id_id);
        cmd.Parameters.AddWithValue("@_sil_stud_id", sdlBAL.sil_stud_id);
        cmd.Parameters.AddWithValue("@_sil_verification_status", sdlBAL.sil_verification_status);
        cmd.Parameters.AddWithValue("@_institute_code_no", sdlBAL.institute_code_no);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        con.Close();
        con.Dispose();
        return id;
    }
    public DataSet student_institute_link_data_fill_verification_state(student_institute_link_BAL sdlBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from institute_and_institute_link_studant_data_fill_view where sil_verification_status=@st and sil_id_id=@sinid", con);
        cmd.Parameters.AddWithValue("@st", sdlBAL.sil_verification_status);
        cmd.Parameters.AddWithValue("@sinid", sdlBAL.sil_id_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet student_institute_link_data_fill_verification_state_studant_data(student_institute_link_BAL sdlBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from institute_and_institute_link_studant_data_fill_view where sil_stud_id=@stdid", con);
        cmd.Parameters.AddWithValue("@stdid", sdlBAL.sil_stud_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet student_institute_link_data_fill_verification_state_studant_data_show_institute(student_institute_link_BAL sdlBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from institute_and_institute_link_studant_data_fill_view where sil_verification_status=@st and sil_stud_id=@stdid", con);
        cmd.Parameters.AddWithValue("@st", sdlBAL.sil_verification_status);
        cmd.Parameters.AddWithValue("@stdid", sdlBAL.sil_stud_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public string student_institute_link_update_verification_state(student_institute_link_BAL sdlBAL)
    {
        mycon();
        cmd = new MySqlCommand("update student_institute_link set sil_verification_status=@st where sil_id=@sid", con);
        cmd.Parameters.AddWithValue("@st", sdlBAL.sil_verification_status);
        cmd.Parameters.AddWithValue("@sid", sdlBAL.sil_id);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
        return "update";
    }
}

//video data fill
public class video_master_DAL : connection
{
    public int video_master_insert(video_master_BAL vmBAL)
    {
        mycon();
        cmd = new MySqlCommand("video_master_add_Update", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_video_id", vmBAL.video_id);
        cmd.Parameters.AddWithValue("@_video_institute_id", vmBAL.video_institute_id);
        cmd.Parameters.AddWithValue("@_video_standard_id", vmBAL.video_standard_id);
        cmd.Parameters.AddWithValue("@_video_third_topic_id", vmBAL.video_third_topic_id);
        cmd.Parameters.AddWithValue("@_video_medium_id", vmBAL.video_medium_id);
        cmd.Parameters.AddWithValue("@_video_board_id", vmBAL.video_board_id);
        cmd.Parameters.AddWithValue("@_video_language_id", vmBAL.video_language_id);
        cmd.Parameters.AddWithValue("@_video_link", vmBAL.video_link);
        cmd.Parameters.AddWithValue("@_video_title", vmBAL.video_title);
        cmd.Parameters.AddWithValue("@_video_description", vmBAL.video_description);
        cmd.Parameters.AddWithValue("@_video_meta_tag", vmBAL.video_meta_tag);
        cmd.Parameters.AddWithValue("@_video_thumbnail_image", vmBAL.video_thumbnail_image);
        cmd.Parameters.AddWithValue("@_video_insdt", vmBAL.video_insdt);
        cmd.Parameters.AddWithValue("@_video_insip", vmBAL.video_insip);
        cmd.Parameters.AddWithValue("@_video_insrid", vmBAL.video_insrid);
        cmd.Parameters.AddWithValue("@_video_logdt", vmBAL.video_logdt);
        cmd.Parameters.AddWithValue("@_video_logip", vmBAL.video_logip);
        cmd.Parameters.AddWithValue("@_video_logrid", vmBAL.video_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        con.Close();
        con.Dispose();
        return id;
    }
    public DataSet video_master_data_fill()
    {
        mycon();
        cmd = new MySqlCommand("Select * from video_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet video_master_data_fill_instituteid(video_master_BAL vmBAL)
    {
        mycon();
        cmd = new MySqlCommand("Select * from video_all_data_get where video_institute_id=@viid", con);
        cmd.Parameters.AddWithValue("@viid", vmBAL.video_institute_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet video_master_data_fill_instituteid_subject(video_master_BAL vmBAL)
    {
        mycon();
        cmd = new MySqlCommand("SELECT distinct(subject_name),video_institute_id, subject_id , subject_image  FROM video_all_data_get where video_institute_id=@viid", con);
        cmd.Parameters.AddWithValue("@viid", vmBAL.video_institute_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public DataSet video_master_edit(video_master_BAL vmBAL)
    {
        mycon();
        cmd = new MySqlCommand("Select * from video_all_data_get where video_id=@vid", con);
        cmd.Parameters.AddWithValue("@vid", vmBAL.video_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }

    public int video_total_data_fill_institute(video_master_BAL vmBAL)
    {
        mycon();
        cmd = new MySqlCommand("SELECT count(video_id) FROM scoolwhool.video_master where video_institute_id=@vinid", con);
        cmd.Parameters.AddWithValue("@vinid", vmBAL.video_institute_id);
        int totalvodeo = Convert.ToInt16(cmd.ExecuteScalar().ToString());
        con.Close();
        con.Dispose();
        return totalvodeo;
    }
    public int total_video_data_fill()
    {
        mycon();
        cmd = new MySqlCommand("Select count(video_id) from video_master", con);
        int totalvideo = Convert.ToInt16(cmd.ExecuteScalar().ToString());
        con.Close();
        con.Dispose();
        return totalvideo;
    }
}
public class student_details_DAL : connection
{
    public int student_details_insert(student_details_BAL sdBAL)
    {
        mycon();
        cmd = new MySqlCommand("student_master_add_update", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_stud_id", sdBAL.stud_id);
        cmd.Parameters.AddWithValue("@_stud_first_name", sdBAL.stud_first_name);
        cmd.Parameters.AddWithValue("@_stud_middle_name", sdBAL.stud_middle_name);
        cmd.Parameters.AddWithValue("@_stud_last_name", sdBAL.stud_last_name);
        cmd.Parameters.AddWithValue("@_stud_gender", sdBAL.stud_gender);
        cmd.Parameters.AddWithValue("@_stud_mobile_no", sdBAL.stud_mobile_no);
        cmd.Parameters.AddWithValue("@_stud_dob", sdBAL.stud_dob);
        cmd.Parameters.AddWithValue("@_stud_email", sdBAL.stud_email);
        cmd.Parameters.AddWithValue("@_stud_std_id", sdBAL.stud_std_id);
        cmd.Parameters.AddWithValue("@_stud_password", sdBAL.stud_password);
        cmd.Parameters.AddWithValue("@_stud_status", sdBAL.stud_status);
        cmd.Parameters.AddWithValue("@_stud_insdt", sdBAL.stud_insdt);
        cmd.Parameters.AddWithValue("@_stud_insip", sdBAL.stud_insip);
        cmd.Parameters.AddWithValue("@_stud_insrid", sdBAL.stud_insrid);
        cmd.Parameters.AddWithValue("@_stud_logdt", sdBAL.stud_logdt);
        cmd.Parameters.AddWithValue("@_stud_logip", sdBAL.stud_logip);
        cmd.Parameters.AddWithValue("@_stud_logrid", sdBAL.stud_logrid);
        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();
        int id = (int)returnval.Value;
        con.Close();
        con.Dispose();
        return id;
    }
    public DataSet student_details_login_data_fill(student_details_BAL sdBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from student_details where stud_mobile_no=@smono and stud_password=@spass", con);
        cmd.Parameters.AddWithValue("@smono", sdBAL.stud_mobile_no);
        cmd.Parameters.AddWithValue("@spass", sdBAL.stud_password);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet student_details_edit(student_details_BAL sdBAL)
    {
        mycon();
        cmd = new MySqlCommand("Select * from student_details where stud_id=@sid", con);
        cmd.Parameters.AddWithValue("@sid", sdBAL.stud_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public int studant_total_data_fill(student_details_BAL sdBAL)
    {
        mycon();
        if (sdBAL.studant_total_value == "0")
        {
            cmd = new MySqlCommand("select count(stud_id) as totalstudant from student_details", con);
        }
        if (sdBAL.studant_total_value == "1")
        {
            cmd = new MySqlCommand("select count(id_id) as totalstudant from institute_and_institute_link_studant_data_fill_view where id_id=@id", con);
            cmd.Parameters.AddWithValue("id", sdBAL.id_id);
        }
        int totalstudant = Convert.ToInt16(cmd.ExecuteScalar().ToString());
        con.Close();
        con.Dispose();
        return totalstudant;
    }
}

//notice
public class notice_master_DAL : connection
{
    public int notice_master_insert(notice_master_BAL nmBAL)
    {
        mycon();
        cmd = new MySqlCommand("notice_master_add_update", con);
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@_nm_id", nmBAL.nm_id);
        cmd.Parameters.AddWithValue("@_nm_institute_id", nmBAL.nm_institute_id);
        cmd.Parameters.AddWithValue("@_nm_title", nmBAL.nm_title);
        cmd.Parameters.AddWithValue("@_nm_description", nmBAL.nm_description);
        cmd.Parameters.AddWithValue("@_nm_file_upload", nmBAL.nm_file_upload);
        cmd.Parameters.AddWithValue("@_nm_effective_date", nmBAL.nm_effective_date);
        cmd.Parameters.AddWithValue("@_nm_ineffective_date", nmBAL.nm_ineffective_date);
        cmd.Parameters.AddWithValue("@_nm_status", nmBAL.nm_status);
        cmd.Parameters.AddWithValue("@_nm_insdt", nmBAL.nm_insdt);
        cmd.Parameters.AddWithValue("@_nm_insrid", nmBAL.nm_insrid);
        cmd.Parameters.AddWithValue("@_nm_logdt", nmBAL.nm_logdt);
        cmd.Parameters.AddWithValue("@_nm_logrid", nmBAL.nm_logrid);

        MySqlParameter returnval = new MySqlParameter("@_ret", SqlDbType.TinyInt);
        returnval.Direction = ParameterDirection.Output;
        cmd.Parameters.Add(returnval);
        cmd.ExecuteNonQuery();

        int id = (int)returnval.Value;
        con.Close();
        con.Dispose();
        return id;
    }
    public DataSet notice_master_data_fill()
    {
        mycon();
        cmd = new MySqlCommand("select * from notice_master", con);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet notice_master_edit(notice_master_BAL nmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from notice_master where nm_id=@nmid", con);
        cmd.Parameters.AddWithValue("@nmid", nmBAL.nm_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
    public DataSet notice_master_edit_data_instituteid(notice_master_BAL nmBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * from notice_master where nm_institute_id=@iid", con);
        cmd.Parameters.AddWithValue("@iid", nmBAL.nm_institute_id);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        con.Dispose();
        return ds;
    }
}

//task studant
public class student_task_reminder_DAL : connection
{
    public string student_task_reminder_insert(student_task_reminder_BAL strBAL)
    {
        mycon();
        cmd = new MySqlCommand("insert into student_task_reminder values(Null,@ssid,@task,@sst,@sidt,@siid,@sldt,@slip)", con);
        cmd.Parameters.AddWithValue("@ssid", strBAL.str_student_id);
        cmd.Parameters.AddWithValue("@task", strBAL.str_task);
        cmd.Parameters.AddWithValue("@sst", strBAL.str_status);
        cmd.Parameters.AddWithValue("@sidt", strBAL.str_insdt);
        cmd.Parameters.AddWithValue("@siid", strBAL.str_insrid);
        cmd.Parameters.AddWithValue("@sldt", strBAL.str_logdt);
        cmd.Parameters.AddWithValue("@slip", strBAL.str_logrid);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
        return "insert data";
    }
    public DataSet student_task_reminder_data_fill_studant_id(student_task_reminder_BAL strBAL)
    {
        mycon();
        cmd = new MySqlCommand("select * FROM student_task_reminder where str_student_id=@ssid and str_status=@ss", con);
        cmd.Parameters.AddWithValue("@ssid", strBAL.str_student_id);
        cmd.Parameters.AddWithValue("@ss", strBAL.str_status);
        da = new MySqlDataAdapter(cmd);
        ds = new DataSet();
        da.Fill(ds);
        con.Close();
        return ds;
    }
    public string student_task_reminder_data_update(student_task_reminder_BAL strBAL)
    {
        mycon();
        cmd = new MySqlCommand("update student_task_reminder set str_status=@sst where str_id=@sid", con);
        cmd.Parameters.AddWithValue("@sst", strBAL.str_status);
        cmd.Parameters.AddWithValue("@sid", strBAL.str_id);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
        return "update";
    }
    public string student_task_reminder_data_delete(student_task_reminder_BAL strBAL)
    {
        mycon();
        cmd = new MySqlCommand("Delete from student_task_reminder where str_id=@sid", con);
        cmd.Parameters.AddWithValue("@sid", strBAL.str_id);
        cmd.ExecuteNonQuery();
        con.Close();
        con.Dispose();
        return "Delete data";
    }
}
