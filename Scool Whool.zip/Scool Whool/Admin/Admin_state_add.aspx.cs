﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class admin_Admin_state_add : System.Web.UI.Page
{
    void country_data()
    {
        alladdress_get_data_DAL alldata = new alladdress_get_data_DAL();
        DataSet ds = alldata.country_data();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drCountry.DataSource = ds;
            drCountry.DataTextField = "country_name";
            drCountry.DataValueField = "country_id";
            drCountry.DataBind();
            drCountry.Items.Insert(0,"---: Select State :---");
        }
        else
        {
            drCountry.Items.Insert(0, "---Select State--");
        }

    }

    void rptr_gridfilldata()
    {
       
        alladdress_get_data_DAL allDAL = new alladdress_get_data_DAL();
        DataSet ds = allDAL.state_data();

        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["admin_login"] != null)
            {
            country_data();
            rptr_gridfilldata();
            }
            else
            {
                Response.Redirect("Admin_Login.aspx");
            }
        }
    }
    protected void btnevent_Click(object sender, EventArgs e)
    {
        if (drCountry.SelectedIndex  != 0)
        {
            state_master_BAL cmBAL = new state_master_BAL();
            if (hfprdid.Value == "")
            {
                cmBAL.state_id = 0;
            }
            else
            {
                cmBAL.state_id = Convert.ToInt16(hfprdid.Value);
            }
            cmBAL.state_country_id = Convert.ToInt16(drCountry.SelectedValue);
            cmBAL.state_name = txtstatename.Text.Trim().ToUpper();
            cmBAL.state_insdt = System.DateTime.Now.ToString("yyyy/MM/dd");
            cmBAL.state_insrid = Convert.ToInt16(Session["admin_login"].ToString());
            cmBAL.state_logdt = System.DateTime.Now.ToString("yyyy/MM/dd");
            cmBAL.state_logrid = Convert.ToInt16(Session["admin_login"].ToString());

            alladdress_insert_data_DAL allinDAL = new alladdress_insert_data_DAL();
            int val = allinDAL.state_data_insert(cmBAL);
            if (val == 1)
            {
                // show message for alredy exists
                Response.Write("<script>alert('This State is exists.')</script>");

            }
            else if (val == 2)
            {
                // insert
                Response.Write("<script>alert('State data inserted.');window.location.href='Admin_state_add.aspx';</script>");
            }
            else if (val == 3)
            {
                Response.Write("<script>alert('State data updated.');window.location.href='Admin_state_add.aspx';</script>");
            }
        }
        else
        {
            Response.Write("<script>alert('Enter your Country.')</script>");

        }

    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "editdata")
        {
            country_data();
            state_master_BAL stBAL = new state_master_BAL();
            stBAL.state_id = Convert.ToInt16(e.CommandArgument.ToString());

            alladdress_edit_data_DAL aleDAL = new alladdress_edit_data_DAL();
            DataSet ds = aleDAL.state_data_edit(stBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                drCountry.Enabled = false;
                drCountry.SelectedValue=ds.Tables[0].Rows[0]["state_country_id"].ToString();
                txtstatename.Text = ds.Tables[0].Rows[0]["state_name"].ToString();
                hfprdid.Value = ds.Tables[0].Rows[0]["state_id"].ToString();
            }

        }

    }
}