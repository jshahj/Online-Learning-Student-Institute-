﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_Admin_Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin_login"] != null)
        {
            if (!IsPostBack)
            {

            }
        }
        else
        {
            Response.Redirect("~/Admin/Admin_Login.aspx");
        }
    }
    protected void btnsave_Click(object sender, EventArgs e)
    {
        admin_user_masterBAL aumBAL = new admin_user_masterBAL();
        if (Request.QueryString["id"] != null && Request.QueryString["id"].ToString() != "")
        {
            aumBAL.aum_id = Convert.ToInt16(Request.QueryString["id"].ToString());


        }
        else
        {
            aumBAL.aum_id = 0;
        }
        aumBAL.aum_fullname = txtfullname.Text.Trim();
        if (rdomale.Checked == true)
        {
            aumBAL.aum_gender = rdomale.Text;
        }
        else if (rdofemale.Checked == true)
        {
            aumBAL.aum_gender = rdofemale.Text;
        }
        aumBAL.aum_contactno = txtmobile.Text.Trim();
        aumBAL.aum_email = txtemail.Text.Trim();
        aumBAL.aum_password = txtpassword.Text.Trim();
        aumBAL.aum_user_role = 1;
        if (rdoactive.Checked == true)
        {
            aumBAL.aum_status = 1;
        }
        else if (rdodeactive.Checked == true)
        {
            aumBAL.aum_status = 0;
        }
        aumBAL.aum_insdt = System.DateTime.Now;
        aumBAL.aum_insrid = 1;
        aumBAL.aum_logdt = System.DateTime.Now;
        aumBAL.aum_logrid = 1;
        aumBAL.aum_last_login = System.DateTime.Now;
        aumBAL.aum_last_logout = System.DateTime.Now;
    }
}