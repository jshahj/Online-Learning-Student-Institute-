﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_Admin_institute_type : System.Web.UI.Page
{
    void institute_type_master_data_fill_rpt()
    {
        institute_type_master_DAL itmDAL = new institute_type_master_DAL();
        DataSet ds = itmDAL.institute_type_master_data_fill();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {

            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["admin_login"] != null)
            {
                institute_type_master_data_fill_rpt();
            }
            else
            {
                Response.Redirect("Admin_Login.aspx");
            }
        }
    }
    protected void btninstitutetype_Click(object sender, EventArgs e)
    {
        institute_type_masterBAL itmBAL = new institute_type_masterBAL();
        if (hfboardid.Value != null & hfboardid.Value.ToString() != "")
        {
            itmBAL. institute_type_id = Convert.ToInt16(hfboardid.Value.ToString());
        }
        else
        {
            itmBAL.institute_type_id = 0;
        }
        itmBAL.institute_type_name = txtinstitutetype.Text;
        itmBAL.institute_type_insdt = System.DateTime.Now;
        itmBAL.institute_type_insip = "1";
        itmBAL.institute_type_insrid = Convert.ToInt16(Session["admin_login"].ToString());
        itmBAL.institute_type_logdt = System.DateTime.Now;
        itmBAL.institute_type_logip = "1";
        itmBAL.institute_type_logrid = Convert.ToInt16(Session["admin_login"].ToString());

        institute_type_master_DAL itmDAL = new institute_type_master_DAL();
        int val = itmDAL.institute_type_master_insert(itmBAL) ;
        if (val.ToString() == "0")
        {
            Response.Write("<script>alert('Error in server');</script>");
        }
        else if (val.ToString() == "1")
        {
            Response.Write("<script>alert('This Institute exists already');</script>");
        }
        else if (val.ToString() == "2")
        {
            Response.Write("<script>alert('Institute inserted');window.location.href='Admin_institute_type.aspx';</script>");
        }
        else if (val.ToString() == "3")
        {
            Response.Write("<script>alert('Institute data updated.');window.location.href='Admin_institute_type.aspx';</script>");
        }
    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "editdata")
        {
            institute_type_masterBAL itmBAL = new institute_type_masterBAL();
            itmBAL.institute_type_id = Convert.ToInt16(e.CommandArgument.ToString());

            institute_type_master_DAL itmDAL = new institute_type_master_DAL();
            DataSet ds = itmDAL.institute_type_master_edit(itmBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtinstitutetype.Text = ds.Tables[0].Rows[0]["institute_type_name"].ToString();
                hfboardid.Value = ds.Tables[0].Rows[0]["institute_type_id"].ToString();
            }
        }
    }
}