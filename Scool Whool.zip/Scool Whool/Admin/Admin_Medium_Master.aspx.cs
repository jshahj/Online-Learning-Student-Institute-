﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class Admin_Admin_Medium_Master : System.Web.UI.Page
{
    void fillgrid()
    {
        medium_masterDAL mdmDAL = new medium_masterDAL();
        DataSet ds = mdmDAL.get_all_medium();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin_login"] != null)
        {
            if (!IsPostBack)
            {
                fillgrid();
            }
        }
        else
        {
            Response.Redirect("~/Admin/Admin_Login.aspx");
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        medium_masterBAL subjBAL = new medium_masterBAL();
        if (hfsubjid.Value != null & hfsubjid.Value.ToString() != "")
        {
            subjBAL.medium_id = Convert.ToInt16(hfsubjid.Value.ToString());
        }
        else
        {
            subjBAL.medium_id = 0;
        }
        subjBAL.medium_name = txtMediumname.Text.Trim().ToUpper();
        subjBAL.medium_insdt = System.DateTime.Now;
        subjBAL.medium_insip = "1";
        subjBAL.medium_insrid = Convert.ToInt16(Session["admin_login"].ToString());
        subjBAL.medium_logdt = System.DateTime.Now;
        subjBAL.medium_logip = "1";
        subjBAL.medium_logrid = Convert.ToInt16(Session["admin_login"].ToString());
        medium_masterDAL mdmDAL = new medium_masterDAL();
        int rid = mdmDAL.medium_master_add_update(subjBAL);
        if (rid.ToString() == "0")
        {
            Response.Write("<script>alert('Error in server');</script>");
        }
        else if (rid.ToString() == "1")
        {
            Response.Write("<script>alert('This medium exists already');</script>");
        }
        else if (rid.ToString() == "2")
        {
            Response.Write("<script>alert('medium inserted');</script>");
        }
        else if (rid.ToString() == "3")
        {
            Response.Write("<script>alert('medium data updated.');</script>");
        }
        fillgrid();
    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnrptredit")
        {
            medium_masterBAL subjBAL = new medium_masterBAL();
            subjBAL.medium_id = Convert.ToInt16(e.CommandArgument.ToString());
            medium_masterDAL mdmDAL = new medium_masterDAL();
            DataSet ds = mdmDAL.get_single_medium_detail(subjBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                hfsubjid.Value = ds.Tables[0].Rows[0]["medium_id"].ToString();
                txtMediumname.Text = ds.Tables[0].Rows[0]["medium_name"].ToString();
            }
            else
            {
                Response.Write("<script>alert('Such data does not exists');</script>");
            }
        }
    }

}