﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class Admin_Admin_Third_Topic_Master : System.Web.UI.Page
{
    void fillsubjectdropdown()
    {
        subject_masterDAL sbjDAL = new subject_masterDAL();
        DataSet ds = sbjDAL.get_all_subject();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drsubject.DataSource = ds;
            drsubject.DataTextField = "subject_name";
            drsubject.DataValueField = "subject_id";
            drsubject.DataBind();
            drsubject.Items.Insert(0, "--- Select Subject Name ---");
            drsubject.Items[0].Value = "0";

        }
        else
        {
            drsubject.Items.Clear();
        }
    }
    void fill_topic_dropdown()
    {
        topic_masterBAL tpmBAL = new topic_masterBAL();
        tpmBAL.topic_subject_id = Convert.ToInt16(drsubject.SelectedItem.Value);
        topic_masterDAL tpmDAL = new topic_masterDAL();
        DataSet ds = tpmDAL.topic_drop_down_fill(tpmBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drtopic.DataSource = ds;
            drtopic.DataTextField = "topic_name";
            drtopic.DataValueField = "topic_id";
            drtopic.DataBind();
            drtopic.Items.Insert(0, "--- Select Topic Name ---");
            drtopic.Items[0].Value = "0";
        }
        else
        {
            drtopic.Items.Clear();
        }
    }
    void fill_sub_topic_dropdown()
    {
        sub_topic_masterBAL sbtpBAL = new sub_topic_masterBAL();
        sbtpBAL.sub_topic_topic_id = Convert.ToInt16(drtopic.SelectedItem.Value);
        sub_topic_masterDAL sbtpDAL = new sub_topic_masterDAL();
        DataSet ds = sbtpDAL.get_sub_topic_for_dropdownfill(sbtpBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drsubtopic.DataSource = ds;
            drsubtopic.DataTextField = "sub_topic_name";
            drsubtopic.DataValueField = "sub_topic_id";
            drsubtopic.DataBind();
            drsubtopic.Items.Insert(0, "--- Select Sub Topic ---");
            drsubject.Items[0].Value = "0";
        }
        else
        {
            drsubtopic.Items.Clear();
        }
    }
    void fillgrid()
    {
        third_topic_masterDAL thtpDAL = new third_topic_masterDAL();
        DataSet ds = thtpDAL.get_all_third_topic();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin_login"] != null)
        {
            if (!IsPostBack)
            {
                fillsubjectdropdown();
                fillgrid();
            }
        }
        else
        {
            Response.Redirect("~/Admin/Admin_Login.aspx");
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        third_topic_masterBAL thtpBAL = new third_topic_masterBAL();
        if (hfthtopic.Value != null & hfthtopic.Value.ToString() != "")
        {
            thtpBAL.third_topic_id = Convert.ToInt16(hfthtopic.Value.ToString());
        }
        else
        {
            thtpBAL.third_topic_id = 0;
        }
        thtpBAL.third_topic_sub_topic_id = Convert.ToInt16(drsubtopic.SelectedItem.Value);
        thtpBAL.third_topic_name = txtthtp.Text.Trim().ToUpper();
        thtpBAL.third_topic_insdt = System.DateTime.Now;
        thtpBAL.third_topic_insip = "1";
        thtpBAL.third_topic_logrid = Convert.ToInt16(Session["admin_login"].ToString());
        thtpBAL.third_topic_logdt = System.DateTime.Now;
        thtpBAL.third_topic_logip = "1";
        thtpBAL.third_topic_logrid = Convert.ToInt16(Session["admin_login"].ToString());

        third_topic_masterDAL thtpDAL = new third_topic_masterDAL();
        int rid = thtpDAL.third_topic_master_add_update(thtpBAL);
        if (rid.ToString() == "0")
        {
            Response.Write("<script>alert('Error in server');</script>");
        }
        else if (rid.ToString() == "1")
        {
            Response.Write("<script>alert('This third topic exists already');</script>");
        }
        else if (rid.ToString() == "2")
        {
            Response.Write("<script>alert('third topic inserted');</script>");
        }
        else if (rid.ToString() == "3")
        {
            Response.Write("<script>alert('third topic data updated.');</script>");
        }
        fillgrid();
    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnrptredit")
        {
            third_topic_masterBAL thtpBAL = new third_topic_masterBAL();
            thtpBAL.third_topic_id = Convert.ToInt16(e.CommandArgument.ToString());
            third_topic_masterDAL thtpDAL = new third_topic_masterDAL();
            DataSet ds = thtpDAL.get_single_third_topic_detail(thtpBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                hfthtopic.Value = ds.Tables[0].Rows[0]["third_topic_id"].ToString();
                txtthtp.Text = ds.Tables[0].Rows[0]["third_topic_name"].ToString();
                drsubject.Text = ds.Tables[0].Rows[0]["subject_id"].ToString();
                fill_topic_dropdown();
                drtopic.Text = ds.Tables[0].Rows[0]["topic_id"].ToString();
                fill_sub_topic_dropdown();
                drsubtopic.Text = ds.Tables[0].Rows[0]["sub_topic_id"].ToString();
            }
            else
            {
                Response.Write("<script>alert('Such data does not exists');</script>");
            }
        }
    }


    protected void drsubject_SelectedIndexChanged(object sender, EventArgs e)
    {
        fill_topic_dropdown();
    }
    protected void drtopic_SelectedIndexChanged(object sender, EventArgs e)
    {
        fill_sub_topic_dropdown();
    }
}