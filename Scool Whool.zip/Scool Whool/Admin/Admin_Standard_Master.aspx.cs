﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_Admin_Standard_Master : System.Web.UI.Page
{

    void fillgrid()
    {
        standard_masterDAL stdmDAL = new standard_masterDAL();
        DataSet ds = stdmDAL.get_all_standard();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin_login"] != null)
        {
            if (!IsPostBack)
            {

                fillgrid();



            }
        }
        else
        {
            Response.Redirect("~/Admin/Admin_Login.aspx");
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        standard_masterBAL stdmBAL = new standard_masterBAL();
        if (hfstdid.Value != null & hfstdid.Value.ToString() != "")
        {
            stdmBAL.standard_id = Convert.ToInt16(hfstdid.Value.ToString());
        }
        else
        {
            stdmBAL.standard_id = 0;
        }
        stdmBAL.standard_name = txtStandardname.Text.Trim().ToUpper();
        stdmBAL.standard_insdt = System.DateTime.Now;
        stdmBAL.standard_insip = "1";
        stdmBAL.standard_insrid = Convert.ToInt16(Session["admin_login"].ToString());
        stdmBAL.standard_logdt = System.DateTime.Now;
        stdmBAL.standard_logip = "1";
        stdmBAL.standard_logrid = Convert.ToInt16(Session["admin_login"].ToString());
        standard_masterDAL stdmDAL = new standard_masterDAL();
        int rid = stdmDAL.standard_master_add_update(stdmBAL);
        if (rid.ToString() == "0")
        {
            Response.Write("<script>alert('Error in server');</script>");
        }
        else if (rid.ToString() == "1")
        {
            Response.Write("<script>alert('This standard exists already');</script>");
        }
        else if (rid.ToString() == "2")
        {
            Response.Write("<script>alert('Standard inserted');</script>");
        }
        else if (rid.ToString() == "3")
        {
            Response.Write("<script>alert('Standard data updated.');</script>");
        }
        fillgrid();
    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnrptredit")
        {
            standard_masterBAL stdmBAL = new standard_masterBAL();
            stdmBAL.standard_id = Convert.ToInt16(e.CommandArgument.ToString());
            standard_masterDAL stdmDAL = new standard_masterDAL();
            DataSet ds = stdmDAL.get_single_standard_detail(stdmBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                hfstdid.Value = ds.Tables[0].Rows[0]["standard_id"].ToString();
                txtStandardname.Text = ds.Tables[0].Rows[0]["standard_name"].ToString();
            }
            else
            {
                Response.Write("<script>alert('Such data does not exists');</script>");
            }
        }
    }

}