﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_Admin_Language_Master : System.Web.UI.Page
{
    void fillgrid()
    {
        language_masterDAL lngDAL = new language_masterDAL();
        DataSet ds = lngDAL.get_all_language();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin_login"] != null)
        {
            if (!IsPostBack)
            {
                fillgrid();
            }
        }
        else
        {
            Response.Redirect("~/Admin/Admin_Login.aspx");
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        language_masterBAL lngBAL = new language_masterBAL();
        if (hflangid.Value != null & hflangid.Value.ToString() != "")
        {
            lngBAL.language_id = Convert.ToInt16(hflangid.Value.ToString());
        }
        else
        {
            lngBAL.language_id = 0;
        }
        lngBAL.language_name = txtlanguagename.Text.Trim().ToUpper();
        lngBAL.language_insdt = System.DateTime.Now;
        lngBAL.language_insip = "1";
        lngBAL.language_insrid = Convert.ToInt16(Session["admin_login"].ToString());
        lngBAL.language_logdt = System.DateTime.Now;
        lngBAL.language_logip = "1";
        lngBAL.language_logrid = Convert.ToInt16(Session["admin_login"].ToString());
        language_masterDAL lngDAL = new language_masterDAL();
        int rid = lngDAL.language_master_add_update(lngBAL);
        if (rid.ToString() == "0")
        {
            Response.Write("<script>alert('Error in server');</script>");
        }
        else if (rid.ToString() == "1")
        {
            Response.Write("<script>alert('This language exists already');</script>");
        }
        else if (rid.ToString() == "2")
        {
            Response.Write("<script>alert('language inserted');</script>");
        }
        else if (rid.ToString() == "3")
        {
            Response.Write("<script>alert('language data updated.');</script>");
        }
        fillgrid();
    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnrptredit")
        {
            language_masterBAL lngBAL = new language_masterBAL();
            lngBAL.language_id = Convert.ToInt16(e.CommandArgument.ToString());
            language_masterDAL lngDAL = new language_masterDAL();
            DataSet ds = lngDAL.get_single_language_detail(lngBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                hflangid.Value = ds.Tables[0].Rows[0]["language_id"].ToString();
                txtlanguagename.Text = ds.Tables[0].Rows[0]["language_name"].ToString();
            }
            else
            {
                Response.Write("<script>alert('Such data does not exists');</script>");
            }
        }
    }

}