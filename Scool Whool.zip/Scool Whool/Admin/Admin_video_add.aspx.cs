﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.IO;

public partial class Admin_Admin_video_add : System.Web.UI.Page
{

    void standard_data_fill_drop()
    {
        standard_masterDAL smDAL = new standard_masterDAL();
        DataSet ds = smDAL.get_all_standard();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drstandard.DataSource = ds;
            drstandard.DataTextField = "standard_name";
            drstandard.DataValueField = "standard_id";
            drstandard.DataBind();
            drstandard.Items.Insert(0, new ListItem("Select Standard", "0"));
        }
        else
        {
            drstandard.Items.Clear();
        }
    }
    void medium_master_data_fill()
    {
        medium_masterDAL smDAL = new medium_masterDAL();
        DataSet ds = smDAL.get_all_medium();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drmedium.DataSource = ds;
            drmedium.DataTextField = "medium_name";
            drmedium.DataValueField = "medium_id";
            drmedium.DataBind();
            drmedium.Items.Insert(0, new ListItem("Select Medium", "0"));
        }
        else
        {
            drmedium.Items.Clear();
        }
    }
    void board_master_data_fill()
    {
        board_masterDAL smDAL = new board_masterDAL();
        DataSet ds = smDAL.get_all_board();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drboard.DataSource = ds;
            drboard.DataTextField = "board_name";
            drboard.DataValueField = "board_id";
            drboard.DataBind();
            drboard.Items.Insert(0, new ListItem("Select Board", "0"));
        }
        else
        {
            drboard.Items.Clear();
        }
    }
    void language_master_data_fill()
    {
        language_masterDAL lmDAL = new language_masterDAL();
        DataSet ds = lmDAL.get_all_language();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drlanguage.DataSource = ds;
            drlanguage.DataTextField = "language_name";
            drlanguage.DataValueField = "language_id";
            drlanguage.DataBind();
            drlanguage.Items.Insert(0, new ListItem("Select Language", "0"));
        }
        else
        {
            drlanguage.Items.Clear();
        }
    }
    void fillsubjectdropdown()
    {
        subject_masterDAL sbjDAL = new subject_masterDAL();
        DataSet ds = sbjDAL.get_all_subject();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drsubject.DataSource = ds;
            drsubject.DataTextField = "subject_name";
            drsubject.DataValueField = "subject_id";
            drsubject.DataBind();
            drsubject.Items.Insert(0, "Select Subject Name");
            drsubject.Items[0].Value = "0";
        }
        else
        {
            drsubject.Items.Clear();
        }
    }
    void fill_topic_dropdown()
    {
        topic_masterBAL tpmBAL = new topic_masterBAL();
        tpmBAL.topic_subject_id = Convert.ToInt16(drsubject.SelectedItem.Value);
        topic_masterDAL tpmDAL = new topic_masterDAL();
        DataSet ds = tpmDAL.topic_drop_down_fill(tpmBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drmaintopic.DataSource = ds;
            drmaintopic.DataTextField = "topic_name";
            drmaintopic.DataValueField = "topic_id";
            drmaintopic.DataBind();
            drmaintopic.Items.Insert(0, "Select Topic Name");
            drmaintopic.Items[0].Value = "0";
        }
        else
        {
            drmaintopic.Items.Clear();
        }
    }
    void fill_sub_topic_dropdown()
    {
        sub_topic_masterBAL sbtpBAL = new sub_topic_masterBAL();
        sbtpBAL.sub_topic_topic_id = Convert.ToInt16(drmaintopic.SelectedItem.Value);
        sub_topic_masterDAL sbtpDAL = new sub_topic_masterDAL();
        DataSet ds = sbtpDAL.get_sub_topic_for_dropdownfill(sbtpBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drsubtopic.DataSource = ds;
            drsubtopic.DataTextField = "sub_topic_name";
            drsubtopic.DataValueField = "sub_topic_id";
            drsubtopic.DataBind();
            drsubtopic.Items.Insert(0, "Select Sub Topic");
            drsubtopic.Items[0].Value = "0";
        }
        else
        {
            drsubtopic.Items.Clear();
        }
    }
    void fill_third_topic_dropdown()
    {
        third_topic_masterBAL thtpBAL = new third_topic_masterBAL();
        thtpBAL.third_topic_sub_topic_id = Convert.ToInt16(drsubtopic.SelectedItem.Value);
        third_topic_masterDAL tbtpDAL = new third_topic_masterDAL();
        DataSet ds = tbtpDAL.get_third_topic_for_dropdownfill(thtpBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drthirdtopic.DataSource = ds;
            drthirdtopic.DataTextField = "third_topic_name";
            drthirdtopic.DataValueField = "third_topic_id";
            drthirdtopic.DataBind();
            drthirdtopic.Items.Insert(0, "Select Third Topic");
            drthirdtopic.Items[0].Value = "0";
        }
        else
        {
            drthirdtopic.Items.Clear();
        }
    }

    void video_master_data_fill_instituteid_rpt()
    {
        video_master_BAL vmBAL = new video_master_BAL();
        vmBAL.video_institute_id = Convert.ToInt16(Request.QueryString["instid"].ToString());

        video_master_DAL vmDAL = new video_master_DAL();
        DataSet ds = vmDAL.video_master_data_fill_instituteid(vmBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin_login"] != null)
        {
            if (!IsPostBack)
            {
                standard_data_fill_drop();
                fillsubjectdropdown();
                medium_master_data_fill();
                board_master_data_fill();
                language_master_data_fill();
                video_master_data_fill_instituteid_rpt();
            }

        }
        else
        {
            Response.Redirect("Admin_Login.aspx");
        }
    }
    protected void drsubject_SelectedIndexChanged(object sender, EventArgs e)
    {
        fill_topic_dropdown();
    }
    protected void drmaintopic_SelectedIndexChanged(object sender, EventArgs e)
    {
        fill_sub_topic_dropdown();
    }
    protected void btnvideo_Click(object sender, EventArgs e)
    {
        video_master_BAL vmBAL = new video_master_BAL();
        if (hfthtopic.Value != null & hfthtopic.Value.ToString() != "")
        {
            vmBAL.video_id = Convert.ToInt16(hfthtopic.Value.ToString());
        }
        else
        {
            vmBAL.video_id = 0;
        }
        vmBAL.video_institute_id = Convert.ToInt16(Request.QueryString["instid"].ToString());
        vmBAL.video_standard_id = Convert.ToInt16(drstandard.SelectedItem.Value);
        vmBAL.video_medium_id = Convert.ToInt16(drmedium.SelectedItem.Value);
        vmBAL.video_board_id = Convert.ToInt16(drboard.SelectedItem.Value);
        vmBAL.video_third_topic_id = Convert.ToInt16(drthirdtopic.SelectedItem.Value);
        vmBAL.video_language_id = Convert.ToInt16(drlanguage.SelectedItem.Value);
        vmBAL.video_link = txtvideolink.Text;
        vmBAL.video_title = txtvideotitel.Text;
        vmBAL.video_description = txtdiscript.Text;
        vmBAL.video_meta_tag = txtmetateg.Text;
        if (filevideo.HasFile)
        {
            Guid a = Guid.NewGuid();
            hfufdpassextension.Value = Path.GetExtension(filevideo.FileName);
            hfufdpassnewname.Value = a.ToString() + hfufdpassextension.Value;
            filevideo.SaveAs(Server.MapPath("~/Admin/imagevideo/" + hfufdpassnewname.Value));
            vmBAL.video_thumbnail_image = "~/Admin/imagevideo/" + hfufdpassnewname.Value;

            //filevideo.SaveAs(Server.MapPath("~/Admin/imagevideo/" + filevideo.FileName));
            //vmBAL.video_thumbnail_image = "~/Admin/imagevideo/" + filevideo.FileName;
        }
        else
        {
            vmBAL.video_thumbnail_image = imgthb.ImageUrl;
        }
        vmBAL.video_insdt = System.DateTime.Now;
        vmBAL.video_insip = "1";
        vmBAL.video_insrid = Convert.ToInt16(Session["admin_login"].ToString());
        vmBAL.video_logdt = System.DateTime.Now;
        vmBAL.video_logip = "1";
        vmBAL.video_logrid = Convert.ToInt16(Session["admin_login"].ToString());

        video_master_DAL vmDAL = new video_master_DAL();
        int val = vmDAL.video_master_insert(vmBAL);
        if (val.ToString() == "1")
        {
            Response.Write("<script>alert('Video with same title already exists.');</script>");
        }
        else if (val.ToString() == "2")
        {
            Response.Write("<script>alert('Video saved');window.location.href='user_institute_details.aspx';</script>");
        }
        else if (val.ToString() == "3")
        {
            Response.Write("<script>alert('Video updated');window.location.href='user_institute_details.aspx';</script>");
        }

    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "editdata")
        {
            video_master_BAL vmBAL = new video_master_BAL();
            vmBAL.video_id = Convert.ToInt16(e.CommandArgument.ToString());

            video_master_DAL vmDAL = new video_master_DAL();
            DataSet ds = vmDAL.video_master_edit(vmBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {

                lblimagefilld.Visible = true;
                drstandard.Text = ds.Tables[0].Rows[0]["video_standard_id"].ToString();
                drmedium.Text = ds.Tables[0].Rows[0]["video_third_topic_id"].ToString();
                drboard.Text = ds.Tables[0].Rows[0]["video_board_id"].ToString();
                //drsubject.Text = ds.Tables[0].Rows[0]["subject_id"].ToString();
                //drmedium.Text = ds.Tables[0].Rows[0]["medium_id"].ToString();
                //drboard.Text = ds.Tables[0].Rows[0]["language_id"].ToString();
                fillsubjectdropdown();
                drsubject.Text = ds.Tables[0].Rows[0]["subject_id"].ToString();
                fill_topic_dropdown();
                drmaintopic.Text = ds.Tables[0].Rows[0]["topic_id"].ToString();
                fill_sub_topic_dropdown();
                drsubtopic.Text = ds.Tables[0].Rows[0]["sub_topic_id"].ToString();
                fill_third_topic_dropdown();
                drthirdtopic.Text = ds.Tables[0].Rows[0]["third_topic_id"].ToString();
                drlanguage.Text = ds.Tables[0].Rows[0]["video_language_id"].ToString();
                txtvideolink.Text = ds.Tables[0].Rows[0]["video_link"].ToString();
                txtvideotitel.Text = ds.Tables[0].Rows[0]["video_title"].ToString();
                txtdiscript.Text = ds.Tables[0].Rows[0]["video_description"].ToString();
                txtmetateg.Text = ds.Tables[0].Rows[0]["video_meta_tag"].ToString();
                imgthb.ImageUrl = ds.Tables[0].Rows[0]["video_thumbnail_image"].ToString();
                hfthtopic.Value = ds.Tables[0].Rows[0]["video_id"].ToString();

            }
        }
    }
    protected void drsubtopic_SelectedIndexChanged(object sender, EventArgs e)
    {
        fill_third_topic_dropdown();
    }
}