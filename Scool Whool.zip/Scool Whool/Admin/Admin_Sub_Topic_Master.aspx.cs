﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
public partial class Admin_Admin_Sub_Topic_Master : System.Web.UI.Page
{
    void fillsubjectdropdown()
    {
        subject_masterDAL sbjDAL = new subject_masterDAL();
        DataSet ds = sbjDAL.get_all_subject();
        if (ds.Tables[0].Rows.Count > 0)
        {
            drsubject.DataSource = ds;
            drsubject.DataTextField = "subject_name";
            drsubject.DataValueField = "subject_id";
            drsubject.DataBind();
            drsubject.Items.Insert(0, "--- Select Subject Name ---");
            drsubject.Items[0].Value = "0";

        }
        else
        {
            drsubject.Items.Clear();
        }
    }
    void fill_topic_dropdown()
    {
        topic_masterBAL tpmBAL = new topic_masterBAL();
        tpmBAL.topic_subject_id = Convert.ToInt16(drsubject.SelectedItem.Value);
        topic_masterDAL tpmDAL = new topic_masterDAL();
        DataSet ds = tpmDAL.topic_drop_down_fill(tpmBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            drtopic.DataSource = ds;
            drtopic.DataTextField = "topic_name";
            drtopic.DataValueField = "topic_id";
            drtopic.DataBind();
            drtopic.Items.Insert(0, "--- Select Topic Name ---");
            drtopic.Items[0].Value = "0";
        }
        else
        {
            drtopic.Items.Clear();
        }
    }
    void fillgrid()
    {
        sub_topic_masterDAL sbtpDAL = new sub_topic_masterDAL();
        DataSet ds = sbtpDAL.get_all_sub_topic();
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["admin_login"] != null)
        {
            if (!IsPostBack)
            {
                fillsubjectdropdown();
                fillgrid();
            }
        }
        else
        {
            Response.Redirect("~/Admin/Admin_Login.aspx");
        }
    }
    protected void btnadd_Click(object sender, EventArgs e)
    {
        sub_topic_masterBAL sbtpBAL = new sub_topic_masterBAL();
        if (hfsbtpid.Value != null & hfsbtpid.Value.ToString() != "")
        {
            sbtpBAL.sub_topic_id = Convert.ToInt16(hfsbtpid.Value.ToString());
        }
        else
        {
            sbtpBAL.sub_topic_id = 0;
        }
        sbtpBAL.sub_topic_topic_id = Convert.ToInt16(drtopic.SelectedItem.Value);
        sbtpBAL.sub_topic_name = txtsbtpid.Text.Trim().ToUpper();
        sbtpBAL.sub_topic_insdt = System.DateTime.Now;
        sbtpBAL.sub_topic_insip = "1";
        sbtpBAL.sub_topic_insrid = Convert.ToInt16(Session["admin_login"].ToString());
        sbtpBAL.sub_topic_logdt = System.DateTime.Now;
        sbtpBAL.sub_topic_logip = "1";
        sbtpBAL.sub_topic_logrid = Convert.ToInt16(Session["admin_login"].ToString());

        sub_topic_masterDAL sbtpDAL = new sub_topic_masterDAL();
        int rid = sbtpDAL.sub_topic_master_add_update(sbtpBAL);
        if (rid.ToString() == "0")
        {
            Response.Write("<script>alert('Error in server');</script>");
        }
        else if (rid.ToString() == "1")
        {
            Response.Write("<script>alert('This sub topic exists already');</script>");
        }
        else if (rid.ToString() == "2")
        {
            Response.Write("<script>alert('sub topic inserted');</script>");
        }
        else if (rid.ToString() == "3")
        {
            Response.Write("<script>alert('sub topic data updated.');</script>");
        }
        fillgrid();
    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "btnrptredit")
        {
            sub_topic_masterBAL sbtpBAL = new sub_topic_masterBAL();
            sbtpBAL.sub_topic_id = Convert.ToInt16(e.CommandArgument.ToString());
            sub_topic_masterDAL sbtpDAL = new sub_topic_masterDAL();
            DataSet ds = sbtpDAL.get_single_sub_topic_detail(sbtpBAL);
            if (ds.Tables[0].Rows.Count > 0)
            {
                hfsbtpid.Value = ds.Tables[0].Rows[0]["sub_topic_id"].ToString();
                txtsbtpid.Text = ds.Tables[0].Rows[0]["sub_topic_name"].ToString();
                drsubject.Text = ds.Tables[0].Rows[0]["subject_id"].ToString();
                fill_topic_dropdown();
                drtopic.Text = ds.Tables[0].Rows[0]["sub_topic_topic_id"].ToString();
            }
            else
            {
                Response.Write("<script>alert('Such data does not exists');</script>");
            }
        }
    }


    protected void drsubject_SelectedIndexChanged(object sender, EventArgs e)
    {
        fill_topic_dropdown();
    }
}