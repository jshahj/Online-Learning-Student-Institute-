﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_user_institute_details : System.Web.UI.Page
{
    void institute_details_data_fill_rpt()
    {
        institute_details_BAL idBAL = new institute_details_BAL();
        idBAL.id_verification_status = "1";

        institute_details_DAL idDAL = new institute_details_DAL();
        DataSet ds = idDAL.institute_details_data_fill_verification_states(idBAL);
        if (ds.Tables[0].Rows.Count > 0)
        {
            gridrepeater.DataSource = ds;
            gridrepeater.DataBind();
        }
        else
        {
            gridrepeater.DataSource = null;
            gridrepeater.DataBind();
        }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["admin_login"] != null)
            {
                institute_details_data_fill_rpt();
            }
            else
            {
                Response.Redirect("Admin_Login.aspx");
            }
            
        }
    }
    protected void gridrepeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName == "advideo")
        {
            Response.Redirect("Admin_video_add.aspx?instid="+e.CommandArgument.ToString());
        }
    }
}