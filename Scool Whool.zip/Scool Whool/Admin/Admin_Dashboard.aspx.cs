﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Admin_Admin_Dashboard : System.Web.UI.Page
{
    void studant_total_data_fill()
    {
        student_details_BAL sdBAL = new student_details_BAL();
        sdBAL.studant_total_value = "0";

        student_details_DAL sdDAL = new student_details_DAL();
        int totalstudant = sdDAL.studant_total_data_fill(sdBAL);
        if (totalstudant != null)
        {
            lblstudanttotal.Text = totalstudant.ToString();
        }
    }
    void institute_total_data_fill()
    {
        institute_details_BAL idBAL = new institute_details_BAL();
        idBAL.institute_total_value_find = "0";

        institute_details_DAL idDAL = new institute_details_DAL();
        int totalinstitute = idDAL.total_institute_data_fill(idBAL);
        if (totalinstitute != null)
        {
            lblinstitute.Text = totalinstitute.ToString();
        }
    }
    void institute_total_active_data_fill()
    {
        institute_details_BAL idBAL = new institute_details_BAL();
        idBAL.institute_total_value_find = "1";

        institute_details_DAL idDAL = new institute_details_DAL();
        int totalinstitute = idDAL.total_institute_data_fill(idBAL);
        if (totalinstitute != null)
        {
            lblactiveinstitute.Text = totalinstitute.ToString();
        }
    }
    void institute_total_panding_data_fill()
    {
        institute_details_BAL idBAL = new institute_details_BAL();
        idBAL.institute_total_value_find = "2";

        institute_details_DAL idDAL = new institute_details_DAL();
        int totalinstitute = idDAL.total_institute_data_fill(idBAL);
        if (totalinstitute != null)
        {
            lblpendinginstitute.Text = totalinstitute.ToString();
        }
    }
    void institute_total_reject_data_fill()
    {
        institute_details_BAL idBAL = new institute_details_BAL();
        idBAL.institute_total_value_find = "3";

        institute_details_DAL idDAL = new institute_details_DAL();
        int totalinstitute = idDAL.total_institute_data_fill(idBAL);
        if (totalinstitute != null)
        {
            lblrejectinstitute.Text = totalinstitute.ToString();
        }
    }
    void total_video_data_fill()
    {
        video_master_DAL vmDAL = new video_master_DAL();
        int totalvideo = vmDAL.total_video_data_fill();
        if (totalvideo != null)
        {
            lblvideo.Text = totalvideo.ToString();
        }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Session["admin_login"] != null)
            {
                studant_total_data_fill();
                institute_total_data_fill();
                total_video_data_fill();
                institute_total_active_data_fill();
                institute_total_panding_data_fill();
                institute_total_reject_data_fill();
            }
            else
            {
                Response.Redirect("Admin_Login.aspx");
            }
        }
    }
}